# 参数、退出码与已知限制

## 调用

```sh
python3 <技能>/scripts/backup.py [--mount <目录>] <子命令> [选项]
```

| 全局选项 | 说明 |
|---|---|
| `--version` | 打印 `minis-git-backup 1.0.0` |
| `--mount <目录>` | 挂载根，默认 `/var/minis/mounts/Minis`；也可用环境变量 `MINIS_MOUNT` |

无子命令时打印帮助，退出码 `2`。

## 子命令

### init

```sh
backup.py init [--dry]
```

**纯本地**：写 `.gitignore`（内容固定：`projects/`、`skills/`、`restore/`、`bak/`、`__pycache__/` 等）、`git init`、设 `user.name=Minis Agent`/`user.email=agent@local`、建 `.archives/.gitkeep`。不联网、不配远程、不读 token。

`.gitignore` 已存在且内容不同时**不覆盖**，只提示。

### remote

```sh
backup.py remote --url <url> | --show [--dry]
```

| 选项 | 说明 |
|---|---|
| `--url` | `https://github.com/<用户>/<仓库>.git`，已有 `origin` 时 `set-url`，否则 `add` |
| `--show` | 只打印当前 `origin`（不带 `--url` 时默认就是 show） |
| `--dry` | 只打印将设置的值 |

设置时若已设 `BACKUP_GIT_TOKEN`，顺带跑一次 `ls-remote --heads` 验证可达；没设 token 只提示、不报错。

### backup

```sh
backup.py backup [--local] [--dry] [-m <message>]
```

| 选项 | 说明 |
|---|---|
| `--local` | 只 `commit` 不 `push`，仍然删本地包 |
| `--dry` | 只打包，不提交；包留在 `.`.archives/`；**不需要 token** |
| `-m` | 自定义提交信息；默认按实际变动文件自动生成 |
| `--remote` | 覆盖推送地址（默认取 `origin`） |
| `--keep-archives` | 提交后保留本地包（默认删除） |

打包规则：

- 找出所有**含 `.git` 或 `.gitignore` 的目录**作为打包单元，取最外层（父目录是单元时子目录随父一起打）；根目录自己的 `.gitignore` 不算单元；
- 跳过 `.`.archives/`、`restore/`、`bak/` 与本技能自己的目录；
- 单元名：`projects/<名>` → `<名>`；其他顶层路径用 `-` 连接；
- 名里 `[^\w.-]` 的字符替换成 `-`（如 `Bark Notify` → `Bark-Notify`）；
- **整目录打包**：`.git`、未提交文件、新增文件夹全部进包，不跳过任何文件（只跳过符号链接和上一轮的 `.git.tar.gz`）；
- 包内路径相对挂载根，解包后落在原位置。

既无 `.git` 也无 `.gitignore` 的目录不打包，作为普通文件入库。

`.gitignore` 计入打包条件的原因：子目录自带的 `.gitignore`（如 `skills/*/` 里的 `tests/report.md`）会静默过滤文件，且根 `.gitignore` **无法**反向豁免；整目录打包才能保住这些文件。`.gitignore` 由 `render_ignore()` 按当前目录结构生成：只排除 `bak/`、`restore/`、`.DS_Store`、`__pycache__/`、`*.pyc` 以及每个包含 `.git` 的目录。新增目录无需改配置，`backup` 每次都会 `sync_ignore()` 同步。

**提交信息自动生成**：从 `git status --porcelain` 取实际变动，按「新增工程 / 备份工程 / memory 文件 / 其他文件」分组，标题一行、明细逐条；`.gitignore`、`.gitkeep` 不计入，同类超过 5 条写「等」。

**推送前核对远端**（`prepare_sync`）：`git clone --bare` 到临时目录，比较 `refs/heads/<branch>`——

| 情况 | 处理 |
|---|---|
| 远端为空 | 直接推 |
| 本地与远端一致 | 直接推 |
| 远端是本地祖先 | 快进推送 |
| 本地是远端祖先（远端领先） | 终止，提示 `backup.py restore` |
| 双方分叉 | 终止，提示人工检查 |

网络地址（`https://` / `http://` / `git@` / `ssh://`）还会校验 owner/repo 是否等于 `BACKUP_GIT_REPO`；`file://` 与本地路径跳过该校验（离线演练用）。临时目录用完即删。

提交成功后删除**本次生成的**包；`push` 失败时包与提交都保留。

### restore

```sh
backup.py restore [--remote <url>] [--dry]
```

| 选项 | 说明 |
|---|---|
| `--remote` | 覆盖仓库地址，默认取 `origin` |
| `--dry` | 只克隆并解包到临时目录检查，不动根目录 |

流程（严格按序，任何一步失败都不动根目录）：

1. `tempfile.mkdtemp(prefix="minis-restore-")` 建临时目录；
2. `git clone --depth 1 <url> .` 到临时目录，**保留 `.git`**；
3. 递归解 `*.git.tar.gz`（`extractall(filter="data")`）并删包；一个包都没有则直接返回，根目录不变；
4. `move_to_bak()`：把根目录除 `bak/` 外的所有条目 `os.rename` 进 `bak/<YYYY-MM-DD HH-MM>/`（可读时间戳，重名追加 `(2)`），跨设备时退化为复制后删除；
5. `restore_into_root()`：把临时目录的条目铺回根目录，跳过 `.`.archives/`、`restore/`、`bak/` 三个本地产物；
6. 删除临时目录，报告 `bak/` 路径。

`bak/` 永不覆盖：同一分钟跑两次会追加 `-2` 后缀。还原后根目录是可用的 git 仓库（克隆来的 `.git` 已在其中）。

**还原不做脱敏**：`restore` 不调用 `privacy.py`，备份里 memory 是什么样，还原出来就是什么样。

## 退出码

| 码 | 含义 | 常见原因 |
|---|---|---|
| 0 | 成功 | — |
| 1 | 执行失败 | 打包异常、git 命令失败、解包失败、推送被拒 |
| 2 | 用法错误 | 无子命令、未知参数 |
| 3 | 找不到挂载目录 | `--mount` 指向不存在的路径 |
| 4 | 仓库未初始化 | 没跑过 `init` 或挂载根没有 `.git` |
| 5 | 缺 `BACKUP_GIT_TOKEN` 或 `BACKUP_GIT_REPO` | 需要推送/克隆但变量缺失或格式不对；`backup --dry` 与 `backup --local` 不受影响 |

## 已知限制

1. **GitHub 不接受 `.git` 路径**。`git add -f x/.git/y` 会被静默跳过，真嵌套仓库直接报 `does not have a commit checked out`。所以 `.git` 只能以 tar.gz 形式入库，不能裸目录跟踪。
2. **包体随 git 历史增长**。`skill-generator` 单工程（2 个嵌套仓库）约 478 KB，四个工程合计约 1 MB/次；每次提交都是新文件（带时间戳），仓库会缓慢变大。需要时手动 `git rm` 历史包。
3. **嵌套仓库各打一份**：按用户要求不做去重，外层仓库若包含内层工作区（`git add -A` 把内层当普通文件跟踪过），包体会翻倍——这是完整性优先的代价。
4. **`--depth 1` 克隆**：`restore` 只取最新一次提交，历史由包里的 `.git` 提供，不依赖远程历史。
5. **权限位丢失**：挂载盘不保留 unix 权限，解出的 `.git` 文件模式是默认值，不影响 git 使用。
6. **凭据只从环境变量读**：`BACKUP_GIT_TOKEN` 与 `BACKUP_GIT_REPO`，不落盘、不进提交；输出里的 token 会被替换成 `***`。
7. **不做增量**：每次都完整打包每个 `.git`，不比对哈希。
8. **`restore` 不覆盖**：快照目录已存在（同一分钟内跑两次）会直接失败，避免误覆盖。
9. **`tar -tzf` 列点文件要加 `-a`**，否则 `.git` 看着像没进包，容易误判。

## 还原后手动操作示例

```sh
cd /var/minis/mounts/Minis/restore/20261124-0215/projects/skill-generator
git log --oneline -3
# 确认无误后整目录搬回
cp -a . /var/minis/mounts/Minis/projects/skill-generator/
```
