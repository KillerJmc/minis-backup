# 测试说明

## 怎么跑

```sh
python3 tests/run.py              # 全部用例，末行「共 18 项，失败 0 项」
python3 tests/run.py --verbose    # 失败时打印完整输出
python3 tests/run.py --selftest   # 负向自检：把每条用例的期望判反，应当全部变红
```

**每个用例都跑在真实目录的副本上**：先把 `/var/minis/mounts/Minis` 整棵复制到 `tempfile.mkdtemp()`，用 `--mount` 指向副本；真实目录只读，跑完删副本。不需要网络与 token（远程用本地裸仓库冒充）。

全部命令都用 `subprocess.run(argv)` 直接调用，不经过 shell；git 参数按 list 传，不做字符串拼接。

## 副本长什么样

```
<临时目录>/Minis/           ← 真实挂载目录的完整复制
├── .git/                   ← 备份仓库（init 前可能不存在）
├── memory/                 ← 真实记忆，含已脱敏的历史
└── projects/*/             ← 真实工程，各自带 .git（含嵌套）
```

复制时跳过 `archives/`、`restore/`、`bak/`、`__pycache__`，其余原样。测试里临时写入的敏感数据一律用假值（`Secret12345`、`13800001111`），不碰真实凭据。

## 用例字段

| 字段 | 说明 |
|---|---|
| `name` | 对话级描述：用户说什么 → 期望什么 |
| `kind` | 场景类型：`push-repo-missing` / `push-mismatch` / `push-remote-ahead` / `push-fastforward` / `init` / `init-dry` / `init-twice` / `remote-set` / `usage` / `backup-dry` / `backup-notoken` / `backup-local` / `backup-mask` / `scan-clean` / `scan-dirty` / `restore-local` / `restore-then-backup` |
| `expect` | 输出里必须出现的字符串列表 |
| `rc` | 期望退出码，默认 0 |
| `pack_deleted` | 断言 `archives/` 里没有 `.git.tar.gz` |
| `pack_kept` | 断言 `archives/` 里仍有包 |
| `git_clean` | 断言挂载根 `git status --porcelain` 为空 |
| `assert_file` | 断言沙箱里存在这些路径 |

## 覆盖了什么

- 正常路径：建仓库、打包、提交、克隆还原；
- 边界：嵌套仓库去重、包名时间戳、`--dry` 不提交；
- 异常：未初始化（rc=4）、缺 token（rc=5）、未知子命令（rc=2）；
- 幂等：重复 `init` 不重写已正确的 `.gitignore`；
- 破坏性动作：只在成功后删包，失败时保留（`--dry` 用例断言 `pack_kept`）。

`T13`/`T14` 覆盖自动还原：断言 `bak/<时间戳>/` 里原封不动保留了还原前根目录的每一条（含 `.git`），断言还原后 6 个 `.git` 一个不少、仓库能 `git log`、没有残留包、临时目录已清理。

`--selftest` 是防止用例写成「实现怎么做就怎么断言」的自检：把每条期望判反后必须全部失败，若仍有一条通过，说明该用例的断言太松。
