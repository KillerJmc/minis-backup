#!/usr/bin/env python3
"""对 memory 文件做脱敏：手机号 / 长 hex / 账号行。

规则：只保留首尾各一个字符，中间全部替换成 *。
"""

import re
import sys


def mask(value, head=1, tail=1):
    if len(value) <= head + tail:
        return "*" * len(value)
    return value[:head] + "*" * (len(value) - head - tail) + value[-tail:]


def mask_phone(line):
    return re.sub(r"(?<!\d)(1[3-9]\d{9})(?!\d)", lambda m: mask(m.group(1)), line)


def mask_hex(line):
    return re.sub(r"(?<![0-9a-fA-F])[0-9a-fA-F]{32,}(?![0-9a-fA-F])",
                  lambda m: mask(m.group(0)), line)


def mask_account(line):
    # 「账号 KillerJmc，」→「账号 K********，」
    return re.sub(r"(账号\s*)([A-Za-z][A-Za-z0-9_]{2,})",
                  lambda m: m.group(1) + mask(m.group(2)), line)


def process(path, dry=False):
    with open(path, encoding="utf-8") as f:
        lines = f.readlines()
    out, changed = [], []
    for i, line in enumerate(lines, 1):
        new = mask_account(mask_hex(mask_phone(line)))
        if new != line:
            changed.append((i, line.rstrip("\n"), new.rstrip("\n")))
        out.append(new)
    if changed and not dry:
        with open(path, "w", encoding="utf-8") as f:
            f.writelines(out)
    return changed


if __name__ == "__main__":
    dry = "--dry" in sys.argv
    for p in [a for a in sys.argv[1:] if not a.startswith("-")]:
        hits = process(p, dry)
        print("%s：%d 处待脱敏%s" % (p, len(hits), "（预演）" if dry else "，已改写"))
        for n, _old, new in hits:
            print("  第 %d 行 → %s" % (n, new.strip()))
