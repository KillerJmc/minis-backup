# 设计稿与实测记录（2026-11-24）

## 用户拍板的三条

1. `.gitignore` 里包含 `restore/`，忽略它；
2. 包名 `<工程名>-<可读时间戳>.git.tar.gz`，递归查找 `.git` 打包/解包；
3. 挂载文件夹根目录就是仓库根。

## 实测：GitHub 与 git 对 `.git` 的态度

| 试验 | 结果 |
|---|---|
| `git add -A -f .`，子目录里有真 `.git` | `error: 'sub/' does not have a commit checked out`，整体失败 |
| `git add -f sub/.git/HEAD`（伪造的 `.git` 目录） | 静默跳过，`ls-files` 里没有该文件，`check-ignore` 也查不到 |
| `git check-ignore -v sub/.git/HEAD` | rc=1，不算被忽略，但就是加不进去 |

结论：`.git` 是不可能被 git 跟踪的，只能以压缩包形式入库。

## 实测：打包方式

| 试验 | 结果 |
|---|---|
| busybox tar `--exclude='skill-generator/skill-generator/.git'` | **无效**，273 个条目一个没排掉 |
| `tar -czf x.tgz -C . deep`（deep 内有多个 .git） | 全部打进去，包括嵌套的，无法只取某个 `.git` |
| Python `tarfile` 用 `t.add(p, arcname=…)` 逐个文件 | 路径可控 |
| Python 直接 `tarinfo` 构造目录项 | **必须自己构 DIRTYPE**，否则祖先目录项缺失 |
| 打包顺序（内层先 / 外层先） | 解包结果一致，但外层先打会重复包含内层 |
| `tar -tzf` 列目录下的点文件 | 默认不显示 `.git`，需 `-a`，容易误判成「没打包成功」 |

结论：用 Python `tarfile` 自定义 DIRTYPE 的目录项，逐个 `.git` 精确打包，跳过被上层覆盖的子仓库。

## 体积参考

- `projects/skill-generator` 单独打包（含 `.git`，505 个条目）≈ 527 KB
- 四个工程合计约 1 MB / 次

## 被否决的方案

- **裸推送 `.git` 目录**：技术上不可行。
- **git bundle**：只含已提交内容，工作区未提交改动会丢。
- **子模块**：需要建 4–6 个远程仓库，每次改动推两次。
- **收集所有 `.git` 再分别打包**：会重复打包嵌套历史（包体翻倍），已改为只打最外层。
