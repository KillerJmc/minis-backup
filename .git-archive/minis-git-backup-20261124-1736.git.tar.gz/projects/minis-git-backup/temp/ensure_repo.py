RC_NEED_CONFIRM = 6


def business_entries(root):
    """挂载根里除本技能产物之外的条目。"""
    out = []
    for name in sorted(os.listdir(root)):
        if name in (ARCHIVES_DIR, ".archives", "archives", "restore", "bak"):
            continue
        out.append(name)
    return out


def ensure_repo(root, tok, owner, name):
    """推送前确认本地顶层有 .git。

    返回 (状态, 说明)：
      "local"    本地已是仓库
      "imported" 本地为空，已把远程克隆内容整份导入（含 .git）
    本地非空又不含 .git 时，抛 Fail(RC_NEED_CONFIRM) 并把清单交给用户决定。
    """
    if is_repo(root):
        return "local", ""

    url = "https://github.com/%s/%s.git" % (owner, name)
    stage = tempfile.mkdtemp(prefix="minis-import-")
    try:
        rc, out, err = git(stage, "clone", "--depth", "1", authed_url(url, tok), ".", check=False)
        if rc != 0:
            msg = "本地没有 .git，尝试从远程恢复失败：%s" % mask(err or out, tok)
            hint = explain_push_error(err or out)
            if hint:
                msg += "\n原因：%s" % hint
            raise Fail(msg)
        shutil.rmtree(os.path.join(stage, ".git"), ignore_errors=True)

        entries = business_entries(root)
        if entries:
            raise Fail(
                "本地顶层没有 .git，但目录里已有 %d 个条目：%s\n"
                "远程有备份，直接导入会覆盖这些内容，所以先停下。\n"
                "请选择：\n"
                "  1) 跑 backup.py restore —— 现有内容整体移入 bak/ 后还原备份（不丢文件）\n"
                "  2) 跑 backup.py init —— 只建本地空仓库，远程备份不导入\n"
                "  3) 自己手工整理目录后再跑 backup"
                % (len(entries), "、".join(entries[:6]) + (" 等" if len(entries) > 6 else "")),
                RC_NEED_CONFIRM)

        moved = 0
        for item in sorted(os.listdir(stage)):
            shutil.move(os.path.join(stage, item), os.path.join(root, item))
            moved += 1
        return "imported", "本地为空，已从远程导入 %d 个条目（含 .git）" % moved
    finally:
        shutil.rmtree(stage, ignore_errors=True)