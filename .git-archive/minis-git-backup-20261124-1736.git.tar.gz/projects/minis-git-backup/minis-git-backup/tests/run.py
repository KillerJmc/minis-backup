#!/usr/bin/env python3
"""minis-git-backup 测试：每次都在真实挂载目录的副本上跑。

流程：把 /var/minis/mounts/Minis 原样复制到临时目录 → 在副本上执行用例
→ 断言 → 删副本。真实目录只读，一个字节都不改。

用法：
  python3 tests/run.py              # 跑 cases.json
  python3 tests/run.py --verbose    # 失败时打印完整输出
  python3 tests/run.py --selftest   # 负向自检：期望判反后必须全部变红
  MINIS_SRC=<目录>                  # 覆盖被测源目录
"""

import json
import os
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL = os.path.dirname(HERE)
SCRIPT = os.path.join(SKILL, "scripts", "backup.py")
CASES = os.path.join(HERE, "cases.json")
SRC = os.environ.get("MINIS_SRC", "/var/minis/mounts/Minis")

# 复制时跳过：备份产物与无关缓存（真实目录里本来也没有，防手残留）
# 根 .git 是备份仓库本身（含数个 MB 的包），复制进沙箱既慢又占内存；
# prepare_repo() 会按需重建一个空仓库，不影响任何用例。
ARCH = ".git-archive"   # 与 backup.py 的 ARCHIVES_DIR 保持一致
SKIP_COPY = {ARCH, ".archives", "archives", "restore", "bak", "__pycache__", ".git"}


def run_proc(argv, cwd=None, env=None):
    """执行命令，返回 (rc, 合并输出)。argv 为 list，不经过 shell。"""
    e = dict(os.environ)
    for k in ("BACKUP_GIT_TOKEN", "BACKUP_GIT_REPO", "MINIS_MOUNT", "GITHUB_TOKEN"):
        e.pop(k, None)
    if env:
        e.update({k: v for k, v in env.items() if v is not None})
    try:
        p = subprocess.run(argv, cwd=cwd, env=e, capture_output=True, text=True)
    except FileNotFoundError as exc:
        return 127, str(exc)
    return p.returncode, (p.stdout or "") + (p.stderr or "")


def git(cwd, *args):
    """git 封装：参数按 list 传，不做字符串拼接。"""
    _, out = run_proc(["git"] + list(args), cwd=cwd)
    return out.strip()


MASTER = None            # 整轮只真实复制一次的主副本
MASTER_DIR = None


def _ignore_at_top(top):
    """只跳过挂载根自己的 .git 与产物目录；projects/ 里的 .git 必须保留。"""
    def ignore(directory, names):
        at_top = os.path.abspath(directory) == os.path.abspath(SRC)
        skip = set()
        for n in names:
            if n in SKIP_COPY and (n != ".git" or at_top):
                skip.add(n)
        return skip
    return ignore


def build_master():
    """把真实挂载目录完整复制一次，作为整轮测试的主副本。"""
    global MASTER, MASTER_DIR
    if MASTER is not None:
        return MASTER
    if not os.path.isdir(SRC):
        raise SystemExit("找不到被测目录：%s" % SRC)
    MASTER_DIR = tempfile.mkdtemp(prefix="mgb-master-")
    MASTER = os.path.join(MASTER_DIR, "Minis")
    shutil.copytree(SRC, MASTER, symlinks=True, ignore=_ignore_at_top(SRC))
    return MASTER


def _clone_dir(src, dst):
    """硬链接复制（秒级）；memory/ 走真实复制，因为脱敏会原地改写文件。"""
    os.makedirs(dst)
    for n in sorted(os.listdir(src)):
        s, d = os.path.join(src, n), os.path.join(dst, n)
        if n == "memory":
            shutil.copytree(s, d, symlinks=True)
            continue
        if os.path.islink(s):
            os.symlink(os.readlink(s), d)
        elif os.path.isdir(s):
            _clone_dir(s, d)
        else:
            try:
                os.link(s, d)
            except OSError:
                shutil.copy2(s, d)


def clone_real(base):
    """从主副本派生一个独立沙箱：硬链接快照，改不了主副本的内容。"""
    master = build_master()
    dst = os.path.join(base, "Minis")
    _clone_dir(master, dst)
    return dst


def cleanup_master():
    global MASTER, MASTER_DIR
    if MASTER_DIR:
        shutil.rmtree(MASTER_DIR, ignore_errors=True)
    MASTER = None
    MASTER_DIR = None


def count_git(mount):
    """统计副本里所有 .git 目录（排除备份仓库自己的 .git）。"""
    out = []
    for dp, dns, _ in os.walk(mount):
        for d in dns:
            if d == ".git":
                rel = os.path.relpath(os.path.join(dp, d), mount)
                if rel != ".git":
                    out.append(rel)
        dns[:] = [x for x in dns if x not in (ARCH, ".archives", "archives", "restore", "bak")]
    return sorted(out)


def run(args, mount, env=None):
    """跑被测脚本；args 是字符串时按空白切分，绝不经过 shell。"""
    argv = [sys.executable, SCRIPT, "--mount", mount]
    if args:
        argv += args.split()
    return run_proc(argv, env={**(env or {})})


def check(expect, rc, out, expect_rc=0):
    ok, why = True, []
    needles = [expect] if isinstance(expect, str) else list(expect)
    for n in needles:
        if n not in out:
            ok = False
            why.append("输出缺少 %r" % n)
    if rc != expect_rc:
        ok = False
        why.append("退出码 %d，期望 %d" % (rc, expect_rc))
    return ok, why


def prepare_repo(mount):
    """副本里的仓库可能带着真实 origin，统一重置成干净状态。"""
    if not os.path.isdir(os.path.join(mount, ".git")):
        git(mount, "init", "-q", ".")
    git(mount, "config", "user.name", "T")
    git(mount, "config", "user.email", "t@t")
    git(mount, "remote", "remove", "origin")
    return mount



def setup_origin(mount, base):
    """把副本打包成一次提交，做成裸仓库冒充远程，返回 origin 路径。"""
    prepare_repo(mount)
    run("init", mount)
    # 生成包并提交（--local 会在提交后删包，用 --keep-archives 留住）
    run("backup --local --keep-archives", mount, {"BACKUP_GIT_REPO": "tester/minis-backup"})
    seed = os.path.join(base, "seed")
    shutil.copytree(mount, seed, symlinks=True,
                    ignore=shutil.ignore_patterns("restore", "bak", "__pycache__"))
    git(seed, "init", "-q", ".")
    git(seed, "config", "user.name", "T")
    git(seed, "config", "user.email", "t@t")
    git(seed, "add", "-A")
    git(seed, "commit", "-qm", "seed")
    origin = os.path.join(base, "origin.git")
    run_proc(["git", "clone", "-q", "--bare", seed, origin])
    run("remote --url file://%s" % origin, mount)
    return origin


def setup_push_remote(mount, base):
    """造一个裸仓库当远端，并把副本推到和它一致的状态。返回 (origin, owner, name)。"""
    origin = os.path.join(base, "push-origin.git")
    run_proc(["git", "init", "-q", "--bare", origin])
    owner, name = "tester", "minis-backup"
    run("remote --url", mount)  # 无参数只打印
    git(mount, "remote", "remove", "origin")
    git(mount, "remote", "add", "origin", "https://github.com/%s/%s.git" % (owner, name))
    return origin, owner, name

def case_kind(c):
    return c["kind"]


def run_case(c, mount, verbose=False):
    """返回 (ok, why, out)。"""
    kind = case_kind(c)
    expect_rc = c.get("rc", 0)
    expect = c["expect"]

    if kind == "init-dry":
        prepare_repo(mount)
        rc, out = run("init --dry", mount)
        return (*check(expect, rc, out, expect_rc), out)

    if kind == "init":
        prepare_repo(mount)
        rc, out = run("init", mount)
        ok, why = check(expect, rc, out, expect_rc)
        for f in c.get("assert_file", []):
            path = f if f.startswith(".") else f
            if not os.path.exists(os.path.join(mount, path)):
                ok = False
                why.append("缺少 %s" % path)
        if c.get("assert_no_remote") and git(mount, "remote"):
            ok = False
            why.append("init 不应配置远程")
        return ok, why, out

    if kind == "init-twice":
        prepare_repo(mount)
        run("init", mount)
        rc, out = run("init", mount)
        return (*check(expect, rc, out, expect_rc), out)

    if kind == "remote-set":
        prepare_repo(mount)
        run("init", mount)
        rc, out = run("remote --url https://example.invalid/a/b.git", mount)
        rc2, out2 = run("remote --show", mount)
        return (*check(expect, rc, out + out2, expect_rc), out + out2)

    if kind == "usage":
        prepare_repo(mount) if c.get("need_repo") else None
        rc, out = run(c.get("args", ""), mount)
        return (*check(expect, rc, out, expect_rc), out)

    if kind == "backup-dry":
        prepare_repo(mount)
        run("init", mount)
        n = len(count_git(mount))
        rc, out = run("backup --dry", mount)
        ok, why = check(expect, rc, out, expect_rc)
        if ("共 %d 个 .git" % n) not in out:
            ok = False
            why.append("副本里有 %d 个 .git，输出没对上：%s" % (n, out.splitlines()[0][:120]))
        for g in count_git(mount):
            if g not in out:
                ok = False
                why.append("输出没列出 %s" % g)
        left = [f for f in os.listdir(os.path.join(mount, ARCH))
                if f.endswith(".git.tar.gz")] if os.path.isdir(os.path.join(mount, ARCH)) else []
        if not left:
            ok = False
            why.append("期望保留包，但 %s/ 为空" % ARCH + "")
        return ok, why, out

    if kind == "backup-notoken":
        prepare_repo(mount)
        run("init", mount)
        rc, out = run("backup", mount, {"BACKUP_GIT_TOKEN": None})
        return (*check(expect, rc, out, expect_rc), out)

    if kind == "backup-local":
        prepare_repo(mount)
        run("init", mount)
        rc, out = run("backup --local", mount, {"BACKUP_GIT_TOKEN": None})
        ok, why = check(expect, rc, out, expect_rc)
        left = [f for f in os.listdir(os.path.join(mount, ARCH))
                if f.endswith(".git.tar.gz")] if os.path.isdir(os.path.join(mount, ARCH)) else []
        if left:
            ok = False
            why.append("本地包没删干净：%s" % left)
        if git(mount, "status", "--porcelain"):
            ok = False
            why.append("工作区不干净：%s" % git(mount, "status", "--short")[:200])
        return ok, why, out

    if kind == "scan-clean":
        rc, out = run("scan", mount)
        return (*check(expect, rc, out, expect_rc), out)

    if kind == "scan-dirty":
        # 往副本 memory 里塞一条伪造的敏感记录（不是真实数据）
        p = os.path.join(mount, "memory", "9999-99-99.md")
        with open(p, "w", encoding="utf-8") as f:
            f.write("密码=Secret12345 手机 13800001111 key=sk-abcdefghijklmnopqrstuvwx\n")
        rc, out = run("scan", mount)
        ok, why = check(expect, rc, out, expect_rc)
        if "Secret12345" in out or "13800001111" in out:
            ok = False
            why.append("报告里泄露了明文")
        if open(p, encoding="utf-8").read() == "":
            ok = False
            why.append("scan 不该改文件")
        rc2, out2 = run("scan --fix", mount)
        body = open(p, encoding="utf-8").read()
        if "Secret12345" in body or "13800001111" in body or "abcdefghijklmnopqrstuvwx" in body:
            ok = False
            why.append("--fix 之后仍有明文")
        if "*********" not in body:
            ok = False
            why.append("密码没有全星号")
        os.remove(p)
        return ok, why, out + out2

    if kind == "backup-mask":
        prepare_repo(mount)
        run("init", mount)
        p = os.path.join(mount, "memory", "9999-99-98.md")
        with open(p, "w", encoding="utf-8") as f:
            f.write("密码=Secret12345\n")
        rc, out = run("backup --local", mount, {"BACKUP_GIT_TOKEN": None})
        ok, why = check(expect, rc, out, expect_rc)
        body = open(p, encoding="utf-8").read()
        if "Secret12345" in body:
            ok = False
            why.append("backup 没有脱敏")
        if "脱敏清单" not in out:
            ok = False
            why.append("推送后没有汇报脱敏清单")
        os.remove(p)
        return ok, why, out

    if kind == "push-mismatch":
        prepare_repo(mount)
        run("init", mount)
        base = os.path.dirname(mount)
        origin, owner, name = setup_push_remote(mount, base)
        env = {"BACKUP_GIT_TOKEN": "fake", "BACKUP_GIT_REPO": "other/repo"}
        rc, out = run("backup", mount, env)
        ok, why = check(expect, rc, out, expect_rc)

    if kind == "push-repo-missing":
        prepare_repo(mount)
        run("init", mount)
        rc, out = run("backup", mount, {"BACKUP_GIT_TOKEN": None, "BACKUP_GIT_REPO": None})
        return (*check(expect, rc, out, expect_rc), out)

    if kind == "push-mismatch":
        prepare_repo(mount)
        run("init", mount)
        base = os.path.dirname(mount)
        origin, owner, name = setup_push_remote(mount, base)
        env = {"BACKUP_GIT_TOKEN": "fake", "BACKUP_GIT_REPO": "other/repo"}
        rc, out = run("backup", mount, env)
        return (*check(expect, rc, out, expect_rc), out)

    if kind == "push-remote-ahead":
        prepare_repo(mount)
        run("init", mount)
        base = os.path.dirname(mount)
        origin, owner, name = setup_push_remote(mount, base)

        # 在克隆出的临时工作区里给远程造一个本地没有的提交
        scratch = os.path.join(base, "ahead-scratch")
        run_proc(["git", "clone", "-q", origin, scratch])
        git(scratch, "config", "user.name", "T")
        git(scratch, "config", "user.email", "t@t")
        with open(os.path.join(scratch, "from-elsewhere.txt"), "w", encoding="utf-8") as f:
            f.write("remote only\n")
        git(scratch, "add", "-A")
        git(scratch, "commit", "-qm", "remote-only")
        git(scratch, "push", "-q", "origin", "HEAD:master")

        rc, out = run("backup --remote file://%s" % origin, mount,
                      {"BACKUP_GIT_TOKEN": "fake", "BACKUP_GIT_REPO": "%s/%s" % (owner, name)})
        ok, why = check(expect, rc, out, expect_rc)
        return ok, why, out

    if kind == "push-fastforward":
        prepare_repo(mount)
        run("init", mount)
        base = os.path.dirname(mount)
        origin, owner, name = setup_push_remote(mount, base)
        rc, out = run("backup --remote file://%s" % origin, mount,
                      {"BACKUP_GIT_TOKEN": "fake", "BACKUP_GIT_REPO": "%s/%s" % (owner, name)})
        ok, why = check(expect, rc, out, expect_rc)
        if ok and not git(origin, "log", "--oneline", "-1"):
            ok = False
            why.append("远端没有收到提交")
        return ok, why, out

    if kind == "pack-whole":
        prepare_repo(mount)
        # 造一个新增目录（无 .git）与一个含未提交文件的仓库目录
        newdir = os.path.join(mount, "newdir-20261124")
        os.makedirs(newdir)
        with open(os.path.join(newdir, "note.txt"), "w", encoding="utf-8") as f:
            f.write("plain\n")
        repo_proj = os.path.join(mount, "projects", "skill-generator")
        untracked = os.path.join(repo_proj, "untracked.txt")
        with open(untracked, "w", encoding="utf-8") as f:
            f.write("not committed\n")

        run("init", mount)
        rc, out = run("backup --local --keep-archives", mount, {"BACKUP_GIT_REPO": "tester/minis-backup"})
        ok, why = check(expect, rc, out, expect_rc)

        # 1) 含 .git 的目录：整目录进包（含 .git 与未提交文件），仓库不跟踪它
        packs = sorted(f for f in os.listdir(os.path.join(mount, ARCH))
                       if f.endswith(".git.tar.gz"))
        if not packs:
            ok, why = False, why + ["没有生成压缩包"]
        else:
            joined = "\n".join(run_proc(["tar", "-tzf", os.path.join(mount, ARCH, p)])[1]
                               for p in packs)
            if "projects/skill-generator/.git/" not in joined:
                ok = False
                why.append("包内缺少 .git")
            if not any("untracked.txt" in line for line in joined.splitlines()):
                ok = False
                why.append("包内缺少未提交文件")
            tracked = git(mount, "ls-files", "projects/skill-generator")
            if tracked:
                ok = False
                why.append("含 .git 的目录不该被仓库跟踪，却跟踪了 %d 个文件" % len(tracked.splitlines()))
            if not any(".git" in line for line in joined.splitlines()):
                ok = False
                why.append("包内没有 .git 路径")

        # 2) 不含 .git 的新目录：作为普通文件入库
        git(mount, "add", "-A")
        tracked_new = git(mount, "ls-files", "newdir-20261124")
        if "note.txt" not in tracked_new:
            ok = False
            why.append("新增的无 .git 目录没有入库")

        os.remove(untracked)
        shutil.rmtree(newdir, ignore_errors=True)
        return ok, why, out

    if kind == "pack-gitignore":
        prepare_repo(mount)
        # 造一个只有 .gitignore、没有 .git 的目录，里面放一个会被忽略的文件
        d = os.path.join(mount, "skills", "fake-skill")
        os.makedirs(os.path.join(d, "tests"))
        with open(os.path.join(d, ".gitignore"), "w", encoding="utf-8") as f:
            f.write("tests/report.md\n")
        with open(os.path.join(d, "SKILL.md"), "w", encoding="utf-8") as f:
            f.write("x\n")
        with open(os.path.join(d, "tests", "report.md"), "w", encoding="utf-8") as f:
            f.write("would be ignored\n")

        run("init", mount)
        rc, out = run("backup --local --keep-archives", mount,
                      {"BACKUP_GIT_REPO": "tester/minis-backup"})
        ok, why = check(expect, rc, out, expect_rc)

        # 该目录应整目录打包（含被 .gitignore 排除的 report.md）
        packs = [f for f in os.listdir(os.path.join(mount, ARCH))
                 if f.startswith("skills-fake-skill-")]
        if not packs:
            ok = False
            why.append("含 .gitignore 的目录没有整目录打包")
        else:
            members = run_proc(["tar", "-tzf", os.path.join(mount, ARCH, packs[0])])[1]
            if "skills/fake-skill/tests/report.md" not in members:
                ok = False
                why.append("包内缺少被 .gitignore 排除的文件")
            if "skills/fake-skill/.gitignore" not in members:
                ok = False
                why.append("包内缺少 .gitignore")
        # 且不出现在提交清单里
        git(mount, "add", "-A")
        tracked = git(mount, "ls-files", "skills/fake-skill")
        if tracked:
            ok = False
            why.append("该目录不该被仓库跟踪，却跟踪了 %s" % tracked.splitlines()[:3])

        shutil.rmtree(d, ignore_errors=True)
        return ok, why, out

    if kind in ("restore-empty", "restore-nonempty"):
        base = os.path.dirname(mount)
        origin = setup_origin(mount, base)   # 远程里含真实备份包
        if os.path.isdir(os.path.join(mount, ".git")):
            shutil.rmtree(os.path.join(mount, ".git"))

        if kind == "restore-empty":  # noqa: E501
            for n in list(os.listdir(mount)):
                q = os.path.join(mount, n)
                shutil.rmtree(q, ignore_errors=True) if os.path.isdir(q) else os.remove(q)
        else:
            os.makedirs(os.path.join(mount, "local-only"), exist_ok=True)
            with open(os.path.join(mount, "local-only", "x.txt"), "w", encoding="utf-8") as f:
                f.write("x\n")

        env = {"BACKUP_GIT_TOKEN": "fake", "BACKUP_GIT_REPO": "tester/minis-backup"}
        rc, out = run("restore --remote file://%s" % origin, mount, env)
        ok, why = check(expect, rc, out, expect_rc)

        if kind == "restore-empty":  # noqa: E501
            if not os.path.isdir(os.path.join(mount, ".git")):
                ok = False
                why.append("整份铺入后应带 .git")
            if not os.path.isdir(os.path.join(mount, "memory")):
                ok = False
                why.append("远程内容没有铺入")
            if os.path.isdir(os.path.join(mount, "bak")):
                ok = False
                why.append("空目录不需要 bak/")
        else:
            if not os.path.isdir(os.path.join(mount, "local-only")):
                ok = False
                why.append("本地内容不该被动")
        return ok, why, out

    if kind in ("restore-local", "restore-then-backup"):
        base = os.path.dirname(mount)
        setup_origin(mount, base)
        before_top = set(os.listdir(mount))
        before_git = count_git(mount)

        rc, out = run("restore", mount,
                      {"BACKUP_GIT_TOKEN": "fake", "BACKUP_GIT_REPO": "tester/minis-backup"})
        restore_out = out
        ok, why = check(["还原完成"] if kind == "restore-then-backup" else expect,
                        rc, out, expect_rc)

        if kind == "restore-local":
            bak_root = os.path.join(mount, "bak")
            baks = sorted(os.listdir(bak_root)) if os.path.isdir(bak_root) else []
            if len(baks) != 1:
                ok = False
                why.append("bak/ 下应有 1 个时间戳目录，实际 %s" % baks)
            else:
                kept = set(os.listdir(os.path.join(bak_root, baks[0])))
                missing = before_top - kept
                if missing:
                    ok = False
                    why.append("bak 里缺少原条目：%s" % sorted(missing))
                if ".git" not in kept:
                    ok = False
                    why.append("根目录的 .git 没有移进 bak")
                import re as _re
                if not _re.fullmatch(r"\d{4}-\d{2}-\d{2} \d{2}-\d{2}", baks[0]):
                    ok = False
                    why.append("bak 目录名不是人类可读格式：%s" % baks[0])
            if not os.path.isdir(os.path.join(mount, ".git")):
                ok = False
                why.append("还原后根目录没有 .git，仓库不可用")
            elif not git(mount, "log --oneline -1"):
                ok = False
                why.append("还原后 git log 读不出来")
            after_git = count_git(mount)
            if sorted(after_git) != sorted(before_git):
                ok = False
                why.append("还原的 .git 不一致：缺 %s 多 %s" %
                           (sorted(set(before_git) - set(after_git)),
                            sorted(set(after_git) - set(before_git))))
            stray = [f for dp, _, fs in os.walk(mount) for f in fs
                     if f.endswith(".git.tar.gz") and "bak" not in dp.split(os.sep)]
            if stray:
                ok = False
                why.append("残留备份包：%s" % stray[:3])
            left = [d for d in os.listdir("/tmp") if d.startswith("minis-restore-")]
            if left:
                ok = False
                why.append("临时目录没清理：%s" % left)
            return ok, why, out

        # T14：还原完再备份一次，必须成功且工作区干净
        rc2, out2 = run("backup --local", mount, {"BACKUP_GIT_TOKEN": None})
        ok2, why2 = check(expect, rc2, out2, expect_rc)
        if rc2 != 0:
            why2.append("还原后再备份失败：" + out2.strip()[-300:])
        return (ok and ok2), (why + why2), restore_out + out2

    return False, ["未知用例类型 %s" % kind], ""


def main():
    selftest = "--selftest" in sys.argv
    verbose = "--verbose" in sys.argv
    cases = json.load(open(CASES, encoding="utf-8"))
    print("被测源：%s" % SRC)
    failed = 0
    for c in cases:
        base = tempfile.mkdtemp(prefix="mgb-")
        try:
            mount = clone_real(base)
            ok, why, out = run_case(c, mount, verbose)
            if selftest:
                ok, why2 = check(c["expect"], 0, "", c.get("rc", 0))
                ok = not ok
                if not ok:
                    why = ["负向自检：该用例期望太松（判反后仍通过）"]
        except Exception as e:
            ok, why, out = False, ["异常：%s" % e], ""
        finally:
            shutil.rmtree(base, ignore_errors=True)
        if ok:
            print("PASS  %s" % c["name"])
        else:
            failed += 1
            print("FAIL  %s" % c["name"])
            for w in why:
                print("      - %s" % w)
            if verbose:
                print(out)
    cleanup_master()
    print("共 %d 项，失败 %d 项" % (len(cases), failed))
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
