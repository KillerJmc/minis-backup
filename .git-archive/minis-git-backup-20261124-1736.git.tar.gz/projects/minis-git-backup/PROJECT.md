# minis-git-backup 技能：做过什么

一句话定位：把 Minis 挂载目录（含各工程的 `.git`）备份到 GitHub，并能从远程取回还原。本文件记录设计决定，接手的人不用翻会话；眼下进度看 `PROGRESS.md`。

## 功能点（用户能主动触发的事）

| 功能 | 触发关键字 | 作用 |
|---|---|---|
| 备份初始化 | 初始化备份、建备份仓库 | 在挂载根建本地 git 仓库与忽略规则（纯本地，不联网） |
| 远程配置 | 配远程、绑定仓库、换地址 | 设置 GitHub 地址并验证可达 |
| 备份提交 | 提交备份、备份一下、推上去 | 打包**所有** `.git` → 提交 → 推送 → 删本地包 |
| 备份下载 | 下载备份、拉回来、还原 | 克隆到临时目录 → 原件移入 `bak/` → 备份铺回根目录 |

## 关键决定

- **`.git` 只能打包装进仓库**：GitHub 拒绝 `.git` 路径，`git add -f x/.git/y` 会被静默跳过（`ls-files` 里根本不存在），真嵌套仓库直接报 `does not have a commit checked out`。所以方案从「原样推送 `.git` 目录」改为「打成 tar.gz 再提交」。
- **压缩用 Python `tarfile` 而不是系统 tar**：busybox tar 的 `--exclude` 在实测里完全没生效（273 个条目一个都没排掉）；`tar x/.git` 也无法只取某个嵌套仓库。Python 逐条 `add(arcname=…)` 才能精确控制包内路径。
- **含 `.git` 的目录整目录打包**：只打 `.git` 会丢掉未提交的文件和新增文件夹（`skills-dist/` 这类）。整目录打包才叫「全部备份」，`.git` 只是包里的一部分。
- **`.gitignore` 也算打包条件**：`skills/*/` 没有 `.git` 但有 `.gitignore`，它会把 `tests/report.md` 静默排除，而根 `.gitignore` 无法反向豁免（实测：子目录规则优先）。改成「含 `.git` 或 `.gitignore` 就整目录打包」，既保住被过滤的文件，也让该目录不再逐文件提交。
- **不含两者的目录走普通文件**：`skills-dist/`、`memory/` 直接入库最省事，新增目录默认被备份。
- **`.gitignore` 动态生成**：写死 `projects/`、`skills/` 会让新目录永远进不了备份。改成按当前目录结构生成，只排除本技能产物与含 `.git` 的目录。
- **覆盖所有 `.git`，不去重**：用户明确要求「压缩要覆盖所有 `.git` 文件夹」。第一版只打最外层以避免重复，被否掉；现在嵌套仓库各自进包，代价是包体可能翻倍（`skill-generator` 2 个仓库共 478 KB），换来的是完整性。
- **初始化只做本地**：用户明确要求「备份初始化只初始化本地，而不是 remote」。`init` 不联网、不读 token、不配远程；远程拆成独立子命令 `remote --url`。
- **仓库根 = 挂载根**：用户明确要求挂载文件夹根目录当仓库根。代价是 `restore/` 会落在仓库内部，因此 `.gitignore` 必须忽略它，否则还原出来的东西会被下次提交当成普通文件带上去。
- **包名带可读时间戳、不覆盖**：`<工程名>-<YYYYMMDD-HHMM>.git.tar.gz`。用户要求的格式；代价是每次提交在 git 历史里留一份新 blob，仓库慢速变大。
- **提交成功后删本地包**：包只是传输载体，提交成功即有据可查；留着会让 `projects/` 旁的 `archives/` 迅速堆积几十 MB。删除只在 `push` 或 `--local` 成功之后执行，失败一律保留。
- **还原是自动的，靠 `bak/` 兜底**：先把根目录所有条目（含 `.git`、隐藏文件）移进 `bak/<时间戳>/`，再把备份铺回来。这样既实现了"还原"又不会丢任何文件，同名冲突也自然消解。第一版是"克隆到 `restore/` 让用户自己搬"，被否掉。
- **克隆的 `.git` 必须铺回**：曾误以为要删掉克隆目录的 `.git`，结果还原后根目录不是仓库、没法继续备份。现在保留它，还原完直接可 `git log` / `backup`。
- **临时目录用系统 /tmp**：克隆内容放在 `tempfile.mkdtemp()`，用完即删；备份包不落在挂载盘里。
- **`bak/` 永不覆盖**：目录名用可读时间戳 `2026-11-24 14-40`，同一分钟多次还原追加 `(2)`，原件一律保留到用户自己清理。
- **`bak/` 不备份**：它是还原前的原件，内容与备份重复且会随每次还原翻倍，明确排除在打包之外。
- **打包跳过 `bak/`**：否则每还原一次，下一次备份就会把整份历史原件再打一遍。
- **只保留两个环境变量**：`BACKUP_GIT_TOKEN` 与 `BACKUP_GIT_REPO`（`作者名/仓库名`）。第一版有 3 个（含 `GIT_AUTHOR_*`），被否掉——备份提交统一署名 `Minis Agent` 就够，作者变量是噪音。
- **`BACKUP_GIT_REPO` 一箭三雕**：拼仓库地址、校验推送目标（防止把备份推到别人的仓库）、还原兜底。比单独存 remote URL 更可靠，因为环境变量不会随目录被替换而失效。
- **推送前必须核对远端**：先把远程 `clone --bare` 到临时目录比对历史。远端领先或分叉一律终止，绝不 force push——备份仓库最怕的就是用旧内容盖掉新备份。
- **变量名统一 `BACKUP_GIT_` 前缀**：`BACKUP_GIT_TOKEN` / `BACKUP_GIT_REPO`，与本技能名对应，一眼能看出属于哪个备份任务。缺变量时给预填链接，不让用户猜。
- **禁止任何回滚远端的操作**：不使用 `git push --force`、不使用 `reset --hard`，测试里移动分支指针也只用 `update-ref`（不碰工作区）。备份仓库的价值全在历史，回滚远端等于销毁备份。
- **提交信息按实际变动生成**：从 `git status --porcelain` 读状态位（`A` 即新增），分出「新增 skill / 新增工程 / 更新 skill / 更新工程 / memory / 其他」；skill 与否按 `projects/<名>/` 下有无 `SKILL.md` 判断，不靠名字猜。`.gitignore`、`.gitkeep` 是标记文件，不计入，否则每条提交都会出现噪音。

## 目录

```
projects/minis-git-backup/            工程层（工程仓库）
├── PROJECT.md                        本文件：为什么这样设计
├── PROGRESS.md                       现在到哪、下一步
├── .gitignore                        排除技能目录与大文件（temp/ 例外）
├── temp/                             设计稿、实测记录（入库）
├── docs/                             调研与设计文档
│   └── github-credentials-design.md  推送变量、token 权限、安全边界
└── minis-git-backup/                 技能层（技能仓库）
    ├── SKILL.md                      功能表 + 五个功能 + 执行约束
    ├── CHANGELOG.md                  变更记录
    ├── references/commands.md        参数、退出码、已知限制
    ├── scripts/backup.py             唯一入口：init / remote / backup / scan / restore
    ├── scripts/privacy.py            敏感信息扫描与脱敏
    ├── tests/{cases.json,run.py,README.md}
    └── .gitignore
```

工程层不放 `WORKFLOW.md` 与 `deploy.py`：流程见技能生成器 `references/git-workflow.md`，部署用 `python3 /var/minis/skills/skill-generator/scripts/deploy.py`。`assets/` 暂不需要，未创建。

## 上线链路

工作副本 `projects/minis-git-backup/minis-git-backup/` → `/var/minis/skills/minis-git-backup/` → `ws.py sync --push` → `/var/minis/mounts/Minis/skills/minis-git-backup/` → `skills-dist/minis-git-backup_v<版本>.zip`

部署用共享脚本，工程里不放副本：

```sh
cd "/var/minis/mounts/Minis/projects/minis-git-backup"
python3 /var/minis/skills/skill-generator/scripts/deploy.py
```

## 遗留

- 不做增量比对，每次都完整打包全部 `.git`；仓库变大后需要 `git rm` 历史包。
- 不自动建 GitHub 仓库、不解决推送冲突。
- `bak/` 只由用户手动清理，脚本不会自动删除任何原件。
