---
name: minis-git-backup
description: 备份初始化，远程配置，备份提交，隐私检查，备份下载
version: 1.0.0
triggers: 初始化备份,配置远程,提交备份,检查隐私,下载备份
---

备份初始化，远程配置，备份提交，隐私检查，备份下载。

## 功能

| 功能 | 触发关键字 | 作用 |
|---|---|---|
| 备份初始化 | 初始化备份、建备份仓库 | 在挂载根建本地 git 仓库与忽略规则（纯本地，不联网） |
| 远程配置 | 配远程、绑定仓库、换地址 | 设置 GitHub 地址并验证可达性 |
| 备份提交 | 提交备份、备份一下、推上去 | 打包所有 `.git` → 隐私脱敏 → 提交 → 推送 → 删本地包 |
| 隐私检查 | 检查隐私、扫一下隐私 | 扫描 memory 的敏感信息，按规则打码 |
| 备份下载 | 下载备份、拉回来、还原 | 克隆到临时目录 → 原件移入 `bak/` → 备份铺回根目录 |

包名、参数、退出码、已知限制见 [`references/commands.md`](references/commands.md)。

**备份的是什么**：`/var/minis/mounts/Minis/` 作为仓库根。

| 内容 | 怎么备份 |
|---|---|
| 含 `.git` **或** `.gitignore` 的目录 | **整目录打成 tar.gz**（连 `.git`、被忽略的文件、未提交文件一起），仓库不重复跟踪该目录 |
| 两者都没有的目录（如 `skills-dist/`、`memory/`） | 作为普通文件直接入库 |

新增的目录**默认就会备份**，不需要改配置：含 `.git` 或 `.gitignore` 就整目录打包，否则当普通文件入库。

把 `.gitignore` 也算进打包条件，是因为它所在目录的忽略规则会静默过滤文件（`tests/report.md` 这类）；整目录打包才能保住这些文件，同时该目录也不再逐个提交。`.gitignore` 由脚本按当前目录结构自动生成，只排除 `archives/` 的包、`bak/`、`restore/` 与缓存。

## 备份初始化

**何时用**：第一次在这台设备上给挂载目录建备份仓库。**纯本地操作，不联网、不配远程、不需要 token。**

```sh
python3 /var/minis/skills/minis-git-backup/scripts/backup.py init
```

做三件事：写 `.gitignore`（忽略 `projects/`、`skills/`、`restore/`）、`git init`、建 `archives/`。

| 输出 | 含义 |
|---|---|
| `已创建：.gitignore, .git/, archives/` | 本次新建了什么 |
| `仓库已存在：<路径>` | 之前初始化过，继续补缺失项 |
| `.gitignore 已存在且内容不同，保持不变` | 有人手动改过，不覆盖，需要时自己对齐 |

`--dry` 只打印将做的动作。

## 远程配置

**何时用**：建好 GitHub 空仓库后绑定地址，或换一个仓库。

```sh
python3 /var/minis/skills/minis-git-backup/scripts/backup.py remote --url https://github.com/<用户名>/<仓库>.git
python3 /var/minis/skills/minis-git-backup/scripts/backup.py remote --show
```

`--show` 只打印当前 `origin`；设置时会顺带用 `BACKUP_GIT_TOKEN` 跑一次 `ls-remote` 验证，没设 token 时只提示不报错。

| 输出 | 含义 |
|---|---|
| `已设置 origin = …` | 地址已写入本地仓库 |
| `远程可访问：…` | token 有效、仓库存在 |
| `远程无法访问：…` | 地址错或 token 无效，先修再提交 |
| `未设置 BACKUP_GIT_TOKEN，推送时会被拒绝` | 地址已存，token 待补 |

## 备份提交

**何时用**：想把当前所有工程（含各自的 git 历史）存到 GitHub。

```sh
python3 /var/minis/skills/minis-git-backup/scripts/backup.py backup
```

做的事：

1. 找出所有**含 `.git` 或 `.gitignore` 的目录**（取最外层，父目录是单元时子目录不再单独成包），跳过 `archives/`、`restore/`、`bak/` 与根目录；
2. 按顶层名称分组，每个工程打成 `archives/<工程名>-<YYYYMMDD-HHMM>.git.tar.gz`，包内保留原始相对路径；
3. **隐私脱敏**：扫描 `memory/` 下的所有 Markdown，命中项就地打码（规则见下），不询问、不中断；
4. `git add` → `commit` → `push`；
6. **提交成功后删除本地包**，`archives/` 恢复为空。

提交信息自动生成，形如：

```
chore(backup): 新增 1 个工程，备份 3 个工程，memory 2 个文件

新增：minis-git-backup
工程：project-workspace、quota-usage、skill-generator
memory：2026-11-23.md、2026-11-24.md
```

`.gitignore` / `.gitkeep` 这类标记文件不计入；明细超过 5 条写「等」。

| 输出 | 含义 |
|---|---|
| `打包 N 个工程，共 M 个 .git 目录` | 总览，M 是实际打进包的仓库数 |
| 缩进的每行 | 该包内包含的 `.git` 路径，逐条列出，可核对没有遗漏 |
| `脱敏 N 处` 加逐条清单 | 提交前打码了哪些内容（只显示打码后的片段） |
| `已提交：chore(backup): …` | 本地提交完成，下一行起是分组明细 |
| `核对远端历史（master）...` | 正在克隆远程比对 |
| `已推送：origin/…` | 远程成功 |
| `本地包已删除（N 个）` | 收尾完成 |

出错怎么办：未初始化 → `先跑 init`；缺 token → 码 5，**加 `--local` 只本地提交**或先配环境变量；推送失败 → 包与提交都保留，修好网络或 token 后重跑。只想看打包结果加 `--dry`（不提交，包留在 `archives/`，也不脱敏）。

## 隐私检查

**何时用**：提交前想先看 memory 里有什么敏感内容；或手动清理。

**只作用于提交链路**：脱敏发生在 `backup` 提交前，`restore` 还原时**不做任何脱敏**——还原就是把备份原样放回来，改不改 memory 由用户自己决定。

```sh
python3 /var/minis/skills/minis-git-backup/scripts/backup.py scan        # 只报告
python3 /var/minis/skills/minis-git-backup/scripts/backup.py scan --fix  # 报告并打码
```

**脱敏是提交的一部分，不询问用户**：`backup` 会在提交前自动脱敏，推送完成后把清单报出来（提交信息里也带一行）。要事前知情就用 `scan` 单独跑。

打码规则——**只留首尾各一个字，中间全部星号；密码类全星号**：

| 类型 | 处理 | 例子 |
|---|---|---|
| 手机号 | 留首尾各一字符 | `1*********5` |
| 账号名 | 留首尾各一字符 | `K*******c` |
| 32 位以上十六进制串 | 留首尾各一字符 | `4******************************1` |
| 邮箱 | 留首尾各一字符 | `a******m` |
| 密码赋值 | **全星号** | `密码=*********` |
| API key / GitHub token / AWS key | **全星号** | `*********************************` |
| JWT / Bearer 令牌 / 私钥块 | **全星号** | `**************************************` |
| IPv4 地址 | 留首尾各一字符 | `1*********1` |

| 输出 | 含义 |
|---|---|
| `memory 扫描：N 处命中` | 命中总数，逐条列出文件名、行号、类型、打码片段 |
| `memory 干净，无需脱敏` | 没有命中 |
| `已脱敏 N 处（K 个文件）` | 打码已写回，文件进 git 备查 |

只改 `memory/` 下的文件；扫描结果永远不打印明文，只有打码片段。

## 备份下载

**何时用**：换设备、误删文件、想把线上备份恢复成当前状态。

```sh
python3 /var/minis/skills/minis-git-backup/scripts/backup.py restore
```

**自动还原，不丢文件**，顺序是：

1. `git clone --depth 1` 到系统临时目录（`/tmp/minis-restore-*`，用完即删）；
2. 解开临时目录里的所有 `*.git.tar.gz` 并删包，这时临时目录就是完整的备份内容（含克隆来的 `.git`）；
3. 把**挂载根现有的所有条目**移进 `bak/<YYYY-MM-DD HH-MM>/`（人类可读）——包括根目录的 `.git`、`.gitignore`、隐藏文件、`memory/`、`projects/`、`skills/`，一件不少；
4. 把临时目录的内容铺回根目录（`bak/`、`archives/` 等本地产物不覆盖）；
5. 报告 `bak/` 路径，由用户确认后自行删除。

| 输出 | 含义 |
|---|---|
| `克隆到临时目录 …` | 正在取远程 |
| `解开 N 个备份包` | 临时目录已展开 |
| `原目录 N 个条目已移入：…/bak/<时间戳>` | 旧内容已安全搬走 |
| `备份已铺回根目录：N 个条目` | 还原完成 |
| `原文件保留在 …，确认无误后可自行删除` | 收尾提示 |

**还原后仓库立即可用**：克隆来的 `.git` 一并铺回，`git log`、`git status` 直接能读，可以接着 `backup`。若需要提交身份，`backup` 会自动补 `user.email`/`user.name`。

出错怎么办：克隆失败不会动根目录一个文件（临时目录删掉即可）；解包失败同样中止，根目录保持原状。先看结果再加 `--dry`（只解包检查，不动根目录）。

## 执行约束

- **仓库根是挂载目录**，不是本技能的工程目录；技能的代码与文档在 `projects/minis-git-backup/`，它本身也会被 `.git` 包进备份。
- **推送要两个环境变量**：`BACKUP_GIT_TOKEN`（凭据）与 `BACKUP_GIT_REPO`（`作者名/仓库名`）。都缺一不可，只读不写盘。
- **缺变量时给引导**：一次列出全部缺失项、用途，并附预填好的设置页链接，用户点开填值即可，不要让他自己猜变量名。
- **绝不 force push、绝不用 `reset --hard`**：推送前比对的临时仓库只用来读，移动本地分支指针只用 `update-ref`。备份仓库里最珍贵的是历史，任何回滚远端的操作都禁止。
- **不替用户判断**：解包后不改名、不搬移、不合并；包名带时间戳，同名工程多次备份会共存。
- **破坏性动作只有一处**：提交成功后删本地包，且只在 `push` 或 `--local` 成功之后删；任何失败都保留。

minis_url: minis://skills/minis-git-backup/SKILL.md
