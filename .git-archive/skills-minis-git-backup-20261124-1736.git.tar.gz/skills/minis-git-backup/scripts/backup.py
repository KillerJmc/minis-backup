#!/usr/bin/env python3
"""minis-git-backup：把 Minis 挂载目录备份到 GitHub，并支持从远程还原。

三个子命令：init / backup / restore。
参数、退出码与已知限制见 ../references/commands.md。
"""

import argparse
import datetime
import os
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile

VERSION = "1.0.0"

# 退出码
RC_OK = 0
RC_FAIL = 1
RC_USAGE = 2
RC_NO_MOUNT = 3
RC_NOT_INIT = 4
RC_NO_TOKEN = 5

MOUNT_ENV = "MINIS_MOUNT"
ARCHIVES_DIR = "archives"
RESTORE_DIR = "restore"
IGNORE_BASE = [
    "# minis-git-backup 自动生成",
    "# 含 .git 或 .gitignore 的目录会整目录打包进 archives/，不在这里重复跟踪",
    "bak/",
    "restore/",
    ".DS_Store",
    "__pycache__/",
    "*.pyc",
]
TEMP_TOP = ("archives", "restore", "bak")


class Fail(Exception):
    def __init__(self, msg, rc=RC_FAIL):
        super().__init__(msg)
        self.rc = rc


def render_ignore(root):
    """生成 .gitignore：基础规则 + 每个打包单元一行，保证其余内容全部入库。"""
    lines = list(IGNORE_BASE)
    if os.path.isdir(root):
        units = find_pack_units(root)
        if units:
            lines.append("")
            lines.append("# 以下目录整目录打包进 archives/，不重复跟踪")
            for u in units:
                lines.append("/%s/" % u.replace(os.sep, "/"))
    return "\n".join(lines) + "\n"


def sync_ignore(root):
    """让 .gitignore 与当前打包单元一致，返回是否发生改写。"""
    path = os.path.join(root, ".gitignore")
    content = render_ignore(root)
    old = ""
    if os.path.exists(path):
        old = open(path, encoding="utf-8").read()
    if old == content:
        return False
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    return True


def mount_root():
    root = os.environ.get(MOUNT_ENV) or "/var/minis/mounts/Minis"
    root = os.path.abspath(root)
    if not os.path.isdir(root):
        raise Fail("找不到挂载目录：%s" % root, RC_NO_MOUNT)
    return root


def git(root, *args, check=True):
    """在 root 里跑 git，返回 (rc, stdout, stderr)。"""
    p = subprocess.run(["git", "-C", root] + list(args),
                       capture_output=True, text=True)
    if check and p.returncode != 0:
        raise Fail("git %s 失败：%s" % (" ".join(args), (p.stderr or p.stdout).strip()))
    return p.returncode, p.stdout.strip(), p.stderr.strip()


def is_repo(root):
    return os.path.isdir(os.path.join(root, ".git"))


ENV_TOKEN = "BACKUP_GIT_TOKEN"
ENV_REPO = "BACKUP_GIT_REPO"

ENV_NOTES = {
    ENV_TOKEN: "minis-git-backup 推送凭据，GitHub fine-grained token（Contents 读写）",
    ENV_REPO: "minis-git-backup 目标仓库，格式：作者名/仓库名",
}


def env_link(key):
    """生成填值的设置页深链：key 预填，值留空等用户填。"""
    from urllib.parse import quote
    return ("minis://settings/environments?create_key=%s&create_value=&create_note=%s"
            % (quote(key), quote(ENV_NOTES[key])))


def env_guide(missing):
    """缺失变量的引导文案：逐个列出用途与填值链接。"""
    lines = ["缺少环境变量，无法继续：", ""]
    for key in missing:
        lines.append("- %s：%s" % (key, ENV_NOTES[key]))
        lines.append("  %s" % env_link(key))
        lines.append("")
    lines.append("打开上面的链接，值留空，填入后保存即可（token 只存本机，不会进仓库）。")
    return "\n".join(lines)


def token():
    return os.environ.get(ENV_TOKEN, "").strip()


def repo_env():
    return os.environ.get(ENV_REPO, "").strip()

def authed_url(url, tok):
    """把 https://github.com/a/b.git 变成带 token 的地址，用于推送。"""
    if not tok or not url.startswith("https://"):
        return url
    rest = url[len("https://"):]
    if "@" in rest.split("/")[0]:
        return url
    return "https://x-access-token:%s@%s" % (tok, rest)


def mask(s, tok):
    return s.replace(tok, "***") if tok else s


def run_remote(root, url, tok, args):
    """用带 token 的 URL 跑一次远程操作，输出里抹掉 token。"""
    rc, out, err = git(root, *args[:1], authed_url(url, tok), *args[1:], check=False)
    return rc, mask(out, tok), mask(err, tok)


# ---------------------------------------------------------------- 备份打包

def find_pack_units(root):
    """找出打包单元：目录里含 `.git` 或 `.gitignore`，整目录打包（含全部文件）。

    只取最外层：父目录已是打包单元时，子目录跟着父一起进包，不单独成包。
    `.gitignore` 也算：它所在目录的忽略规则会静默过滤文件，整目录打包才能保住内容。
    跳过本技能自己的产物目录，跳过根目录（根 `.gitignore` 是脚本生成的）。
    """
    units = []
    for dp, dns, fns in os.walk(root):
        rel = os.path.relpath(dp, root)
        if rel == ".":
            continue
        top = rel.split(os.sep)[0]
        if top in TEMP_TOP:
            dns[:] = []
            continue
        if ".git" in dns or ".gitignore" in fns:
            units.append(rel)
            dns[:] = []  # 不再深入，子目录随父目录一起打包
    return sorted(units)


def git_dirs_inside(base, unit):
    """单元内所有 .git 的相对路径，用于输出核对。"""
    out = []
    full = os.path.join(base, unit)
    for dp, dns, _ in os.walk(full):
        if ".git" in dns:
            out.append(os.path.relpath(os.path.join(dp, ".git"), base))
    return sorted(out)


def unit_name(unit):
    """包文件名用的短名：projects/xxx → xxx；其他路径用连字符拼接（不能含 /）。"""
    parts = unit.split(os.sep)
    if len(parts) == 2 and parts[0] == "projects":
        return parts[1]
    return "-".join(parts)


def unit_label(unit):
    """提交信息里给人看的名字：保留路径前缀，如 `skills/minis-git-backup`。"""
    parts = unit.split(os.sep)
    if len(parts) == 2 and parts[0] == "projects":
        return parts[1]
    return "/".join(parts)


def _norm(rel):
    rel = rel.replace(os.sep, "/")
    while rel.startswith("./"):
        rel = rel[2:]
    return rel


def write_archive(base, unit, out_path):
    """把整个目录（含 .git 与所有文件）打成 tar.gz，保留相对挂载根的路径。"""
    full = os.path.join(base, unit)
    count = 0
    with tarfile.open(out_path, "w:gz") as tar:
        for dp, dns, fns in os.walk(full):
            dns.sort()
            rel_dir = _norm(os.path.relpath(dp, base))
            ti = tarfile.TarInfo(rel_dir)
            ti.type = tarfile.DIRTYPE
            ti.mode = 0o755
            ti.mtime = int(os.stat(dp).st_mtime)
            tar.addfile(ti)
            count += 1
            for n in sorted(fns):
                if n.endswith(".git.tar.gz"):
                    continue  # 别把上一轮的包再打进去
                p = os.path.join(dp, n)
                if os.path.islink(p):
                    continue
                tar.add(p, arcname=_norm(os.path.relpath(p, base)), recursive=False)
                count += 1
    return count

def stamp():
    """包名用的紧凑时间戳。"""
    return datetime.datetime.now().strftime("%Y%m%d-%H%M")


def human_stamp():
    """给人看的目录名：2026-11-24 14-33。"""
    return datetime.datetime.now().strftime("%Y-%m-%d %H-%M")


def archives_root(root):
    return os.path.join(root, ARCHIVES_DIR)


def memory_files(root):
    """memory/ 下所有 Markdown 文件。"""
    mdir = os.path.join(root, "memory")
    out = []
    if not os.path.isdir(mdir):
        return out
    for n in sorted(os.listdir(mdir)):
        if n.endswith(".md"):
            out.append(os.path.join(mdir, n))
    return out


def scan_memory(root, fix=False, quiet=False):
    """扫描 memory；fix=True 时就地打码。

    返回 (命中数, 需处理数, 已改写文件数, 报告行)。
    需处理数只统计 high/medium——low 只提示，不会改写。
    """
    import privacy

    total_hits, fixable, total_changed, lines = 0, 0, 0, []
    for path in memory_files(root):
        try:
            text = open(path, encoding="utf-8").read()
        except UnicodeDecodeError:
            continue
        hits = privacy.scan_text(text)
        if not hits:
            continue
        total_hits += len(hits)
        fixable += sum(1 for h in hits if h[2] in privacy.FIX_SEVERITY)
        if not quiet:
            lines.append("  %s" % os.path.basename(path))
            lines.extend(privacy.report(hits))
        if fix:
            new, changed = privacy.redact_text(text)
            if changed:
                with open(path, "w", encoding="utf-8") as f:
                    f.write(new)
                total_changed += 1
    return total_hits, fixable, total_changed, lines


def cmd_scan(args, root):
    hits, fixable, changed, lines = scan_memory(root, fix=args.fix)
    if hits == 0:
        print("memory 干净，无需脱敏")
        return RC_OK
    print("memory 扫描：%d 处命中（其中 %d 处需脱敏，其余为低风险提示）" % (hits, fixable))
    for line in lines:
        print(line)
    if args.fix:
        if changed:
            print("已脱敏 %d 处（%d 个文件）" % (fixable, changed))
        else:
            print("无需脱敏的条目（命中的都是低风险提示）")
    else:
        print("未改动文件；要打码请加 --fix（backup 会自动做）")
    return RC_OK


def cmd_backup(args, root):
    if not is_repo(root):
        raise Fail("备份仓库还没初始化：先跑 backup.py init", RC_NOT_INIT)
    if not (args.local or args.dry):
        github_env()  # 两个变量一次校验，缺什么一起告诉用户

    if not args.dry and sync_ignore(root):
        print("已按当前目录结构更新 .gitignore（含 .git 的目录打包，其余全部入库）")

    made, adir, ts = make_archives(root, args)

    # 脱敏是提交的一部分：静默执行，推送后汇报
    hits, fixable, changed, lines = scan_memory(root, fix=not args.dry, quiet=True)

    if args.dry:
        if fixable:
            print("预演发现 memory 有 %d 处需脱敏（实际提交时会自动打码）" % fixable)
        elif hits:
            print("预演发现 memory 有 %d 处低风险提示，不会改动" % hits)
        print("（预演，未提交；生成的包保留在 archives/）")
        return RC_OK

    if fixable:
        print("提交前已脱敏 %d 处（%d 个文件）" % (fixable, changed))
    elif hits:
        print("memory 有 %d 处低风险提示（公网地址等），未改动" % hits)

    commit_and_push(root, made, adir, ts, args)

    if hits:
        print("脱敏清单（只显示打码后的片段）：")
        for line in lines:
            print(line)
    return RC_OK


def ensure_identity(root):
    """克隆来的仓库可能缺 user.email，提交前补上本地身份。

    不能靠 `git config` 读来判空（读不到时返回 rc=0 但 stdout 为空），改成直接写。
    """
    git(root, "config", "user.email", "agent@local", check=False)
    git(root, "config", "user.name", "Minis Agent", check=False)


def remote_owner_name(url):
    """从 https://github.com/<owner>/<repo>.git 取出 owner 与 repo。"""
    u = url.rstrip("/")
    if u.endswith(".git"):
        u = u[:-4]
    parts = u.replace(":", "/").split("/")
    if len(parts) < 2:
        raise Fail("无法从地址解析出 作者/仓库名：%s" % url)
    return parts[-2], parts[-1]


def github_env():
    """读取 BACKUP_GIT_TOKEN 与 BACKUP_GIT_REPO；缺失或格式不对时一次性列出全部问题并给填值链接。"""
    tok = token()
    repo = repo_env()
    missing, bad = [], []

    if not tok:
        missing.append(ENV_TOKEN)
    if not repo:
        missing.append(ENV_REPO)
    elif repo.count("/") != 1 or not all(p.strip() for p in repo.split("/")):
        bad.append("%s 格式应为 作者名/仓库名，当前是 %r" % (ENV_REPO, repo))

    if missing or bad:
        msg = []
        if missing:
            msg.append(env_guide(missing))
        if bad:
            msg.append("；".join(bad))
        raise Fail("\n".join(msg), RC_NO_TOKEN)

    owner, name = [p.strip() for p in repo.split("/")]
    return tok, owner, name


def is_network_url(url):
    """本地路径与 file:// 不参与 BACKUP_GIT_REPO 一致性校验（测试与离线演练用）。"""
    return url.startswith(("https://", "http://", "git@", "ssh://"))


def remote_matches(url, owner, name):
    """本地 origin 与环境变量里的仓库是否同一目标。"""
    try:
        r_owner, r_name = remote_owner_name(url)
    except Fail:
        return False
    return r_owner.lower() == owner.lower() and r_name.lower() == name.lower()


def looks_like_skill(root, unit):
    """打包单元里是否含 SKILL.md（本层或下一层）→ 视作 skill。

    unit 是相对挂载根的路径，如 `projects/quota-usage`、`skills/project-workspace`。
    """
    base = os.path.join(root, unit)
    if not os.path.isdir(base):
        return False
    if os.path.isfile(os.path.join(base, "SKILL.md")):
        return True
    try:
        subs = os.listdir(base)
    except OSError:
        return False
    return any(os.path.isfile(os.path.join(base, sub, "SKILL.md")) for sub in subs)


def build_message(root, made):
    """按实际变动的文件生成提交信息。

    标题一行摘要，明细每行「类别：内容」，类别词写清楚是新增还是更新、是 skill 还是工程。
    """
    rc, out, _ = git(root, "status", "--porcelain", check=False)
    entries = [l for l in out.splitlines() if l.strip()]
    if not entries:
        return None
    files = [l[3:].strip().strip('"') for l in entries]
    added = {l[3:].strip().strip('"') for l in entries if l[:2].strip() == "A"}

    # 包名 → 打包单元，用于判定 skill
    unit_of = {}
    for item in made:
        fn, unit = item[0], item[3]
        unit_of[fn] = unit

    skill_new, skill_chg, proj_new, proj_chg, mem_chg, other = [], [], [], [], [], []
    for f in files:
        parts = f.split("/")
        if f.startswith("memory/"):
            mem_chg.append(f)
        elif len(parts) >= 2 and parts[0] == "archives":
            fn = os.path.basename(f)
            unit = unit_of.get(fn)
            if unit is None:  # 上一轮遗留的包
                stem = fn[:-len(".git.tar.gz")]
                name = stem.rsplit("-", 2)[0].strip("-")
                if not name:
                    continue
                unit, label = name, name
            else:
                label = unit_label(unit)
            is_skill = looks_like_skill(root, unit)
            if f in added:
                (skill_new if is_skill else proj_new).append(label)
            else:
                (skill_chg if is_skill else proj_chg).append(label)
        elif os.path.basename(f) in (".gitignore", ".gitkeep"):
            continue  # 标记文件不算内容变动
        else:
            other.append(f)

    def uniq(x):
        return sorted(dict.fromkeys(x))

    skill_new, skill_chg = uniq(skill_new), uniq(skill_chg)
    proj_new, proj_chg = uniq(proj_new), uniq(proj_chg)

    head = []
    if skill_new:
        head.append("新增 %d 个 skill" % len(skill_new))
    if skill_chg:
        head.append("更新 %d 个 skill" % len(skill_chg))
    if proj_new:
        head.append("新增 %d 个工程" % len(proj_new))
    if proj_chg:
        head.append("更新 %d 个工程" % len(proj_chg))
    if mem_chg:
        head.append("memory %d 个文件" % len(mem_chg))
    if other:
        head.append("其他 %d 个目录" % len({f.split("/")[0] if "/" in f else "." for f in other}))
    title = "chore(backup): " + "，".join(head) if head else "chore(backup): 备份"

    def line(label, items, transform=lambda x: x):
        if not items:
            return None
        shown = "、".join(transform(i) for i in items[:5])
        return label + "：" + shown + (" 等" if len(items) > 5 else "")

    def group_tops(paths):
        """其他文件按顶层目录归并，目录内只报个数。"""
        tops = {}
        for f in paths:
            top = f.split("/")[0] if "/" in f else "(根目录)"
            tops[top] = tops.get(top, 0) + 1
        return ["%s（%d 个文件）" % (k, v) for k, v in sorted(tops.items())]

    detail = [d for d in [
        line("新增 skill", skill_new),
        line("新增工程", proj_new),
        line("更新 skill", skill_chg),
        line("更新工程", proj_chg),
        line("memory 变更", mem_chg, os.path.basename),
        line("其他", group_tops(other)),
    ] if d]
    return title, detail

def explain_push_error(err):
    """把 git/GitHub 的常见拒绝翻译成可操作的提示。"""
    low = (err or "").lower()
    if "403" in low or "denied to" in low or "not accessible" in low:
        return ("token 没有该仓库的写权限。去 GitHub → Settings → Developer settings → "
                "Fine-grained tokens → 该 token：Repository access 勾上这个仓库，"
                "Permissions → Contents 设为 Read and write，然后重新保存")
    if "401" in low or "authentication failed" in low or "invalid username" in low:
        return "token 无效或已过期，重新生成并在设置里更新 BACKUP_GIT_TOKEN"
    if "404" in low or "not found" in low:
        return "仓库不存在，或 token 的 Repository access 没有包含它；确认 BACKUP_GIT_REPO 拼写"
    if "timed out" in low or "could not resolve" in low or "network" in low:
        return "网络不可达，检查网络连接后重试"
    return ""


def prepare_sync(root, tok, url, branch):
    """推送前把远程取到临时仓库，确认双方历史对得上。

    返回 (临时仓库路径, 是否可直接快进推送)；不需要合并时临时仓库已清理。
    """
    tmp = tempfile.mkdtemp(prefix="minis-sync-")
    gitdir = os.path.join(tmp, "repo.git")
    rc, out, err = git(tmp, "clone", "--bare", "--quiet", authed_url(url, tok), gitdir, check=False)
    if rc != 0:
        shutil.rmtree(tmp, ignore_errors=True)
        msg = "拉取远程失败：%s" % mask(err or out, tok)
        hint = explain_push_error(err or out)
        if hint:
            msg += "\n原因：%s" % hint
        raise Fail(msg)

    rc, remote_head, _ = git(gitdir, "rev-parse", "--verify", "--quiet",
                             "refs/heads/%s" % branch, check=False)
    if rc != 0 or not remote_head:
        shutil.rmtree(tmp, ignore_errors=True)
        return None, True  # 远程是空的，直接推

    rc, local_head, _ = git(root, "rev-parse", "--verify", "--quiet",
                            "refs/heads/%s" % branch, check=False)
    if rc != 0 or not local_head:
        shutil.rmtree(tmp, ignore_errors=True)
        return None, True

    if local_head == remote_head:
        shutil.rmtree(tmp, ignore_errors=True)
        return None, True

    # 本地领先且远程是祖先 → 快进推送
    rc, _, _ = git(gitdir, "merge-base", "--is-ancestor", remote_head, local_head, check=False)
    if rc == 0:
        shutil.rmtree(tmp, ignore_errors=True)
        return None, True

    # 反向：远程领先本地 → 停止，要求先 restore
    rc, _, _ = git(root, "merge-base", "--is-ancestor", local_head, remote_head, check=False)
    if rc == 0:
        shutil.rmtree(tmp, ignore_errors=True)
        raise Fail("远端有本地没有的提交（提交记录对不上），已终止推送；"
                   "先跑 backup.py restore 还原后再备份")

    shutil.rmtree(tmp, ignore_errors=True)
    raise Fail("本地与远端历史已分叉（提交记录对不上），已终止推送；"
               "先跑 backup.py restore 还原后再备份")


def commit_and_push(root, made, adir, ts, args):
    """先提交（含新包），推送成功后再删本地包并提交一次清理。"""
    ensure_identity(root)
    git(root, "add", "-A")
    built = build_message(root, made)
    if built:
        title, detail = built
        msg = args.message or title
        argv = ["commit", "-m", msg]
        if detail and not args.message:
            argv += ["-m", "\n".join(detail)]
        git(root, *argv)
        print("已提交：%s" % msg)
        for d in detail:
            print("  %s" % d)
    else:
        print("没有可提交的改动（包内容与上次一致）")

    if args.local:
        print("已跳过推送（--local）")
    else:
        push_with_check(root, args)

    # 提交成功之后才删本地包；任何失败都保留
    if args.keep_archives:
        print("本地包已保留（--keep-archives）")
        return
    for fn, *_ in made:
        p = os.path.join(adir, fn)
        if os.path.exists(p):
            os.remove(p)
    print("本地包已删除（%d 个）" % len(made))

    rc, out, _ = git(root, "status", "--porcelain", check=False)
    if out.strip():
        git(root, "add", "-A")
        git(root, "commit", "-m", "chore(backup): 清理本地包")
        print("已提交清理记录，工作区干净")


def push_with_check(root, args):
    """推送前先在临时仓库核对双方历史，确认无误再推。"""
    tok, owner, name = github_env()
    url = args.remote or remote_url(root) or "https://github.com/%s/%s.git" % (owner, name)
    if not remote_url(root) and not args.remote:
        print("未配置 origin，按 BACKUP_GIT_REPO 使用 %s" % url)
    if is_network_url(url) and not remote_matches(url, owner, name):
        raise Fail("推送地址 %s 与 %s=%s/%s 不匹配" % (url, ENV_REPO, owner, name))
    branch = current_branch(root)
    print("核对远端历史（%s）..." % branch)
    prepare_sync(root, tok, url, branch)
    rc, out, err = run_remote(root, url, tok, ["push", "--set-upstream", branch])
    if rc != 0:
        msg = "推送失败：%s" % (err or out)
        hint = explain_push_error(err or out)
        if hint:
            msg += "\n原因：%s" % hint
        raise Fail(msg)
    print("已推送：%s/%s/%s" % (owner, name, branch))


def make_archives(root, args):
    """把每个含 .git 的目录整目录打包（含全部文件与历史）。"""
    units = find_pack_units(root)
    if not units:
        raise Fail("挂载目录下没有找到任何含 .git 的目录")

    adir = archives_root(root)
    os.makedirs(adir, exist_ok=True)
    # 上次推送失败会留下旧包；它们已被新包取代，先清掉避免历史无限膨胀
    stale = [f for f in os.listdir(adir) if f.endswith(".git.tar.gz")]
    for f in stale:
        os.remove(os.path.join(adir, f))
    if stale:
        print("清理上次残留的 %d 个包" % len(stale))
    ts = stamp()
    made = []
    total_git = 0
    for unit in units:
        name = unit_name(unit)
        safe = re.sub(r"[^\w.-]+", "-", name).strip("-") or "unit"
        out = os.path.join(adir, "%s-%s.git.tar.gz" % (safe, ts))
        n = write_archive(root, unit, out)
        gits = git_dirs_inside(root, unit)
        total_git += len(gits)
        made.append((os.path.basename(out), n, os.path.getsize(out), unit, gits))

    print("打包 %d 个目录（整目录含全部文件），共 %d 个 .git：" % (len(made), total_git))
    for fn, n, size, unit, gits in made:
        print("  archives/%s  ·  %d 项  ·  %s  ·  %d 个 .git" % (fn, n, human(size), len(gits)))
        print("    %s/" % unit)
        for g in gits:
            print("      %s" % g)
    return made, adir, ts


def human(n):
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return ("%.0f %s" % (n, unit)) if unit == "B" else ("%.1f %s" % (n, unit))
        n /= 1024.0


# ---------------------------------------------------------------- 初始化

def remote_url(root):
    rc, out, _ = git(root, "remote", "get-url", "origin", check=False)
    return out.strip() if rc == 0 else ""


def current_branch(root):
    rc, out, _ = git(root, "rev-parse", "--abbrev-ref", "HEAD", check=False)
    return out.strip() if rc == 0 and out.strip() != "HEAD" else "master"


def cmd_init(args, root):
    """只初始化本地仓库：不设远程、不联网、不碰 token。"""
    created = []
    gignore = os.path.join(root, ".gitignore")
    content = render_ignore(root)
    if os.path.exists(gignore):
        old = open(gignore, encoding="utf-8").read()
        if old == content:
            print(".gitignore 已是正确内容")
        elif args.dry:
            print("将更新 .gitignore（与当前含 .git 的目录保持一致）")
        else:
            with open(gignore, "w", encoding="utf-8") as f:
                f.write(content)
            created.append(".gitignore（更新）")
            print(".gitignore 已更新：只忽略本技能产物与含 .git 的目录")
    else:
        if args.dry:
            print("将写入 .gitignore")
        else:
            with open(gignore, "w", encoding="utf-8") as f:
                f.write(content)
            created.append(".gitignore")

    if not is_repo(root):
        print("将在 %s 初始化 git 仓库" % root)
        if not args.dry:
            git(root, "init", "-q")
            git(root, "config", "user.name", "Minis Agent", check=False)
            git(root, "config", "user.email", "agent@local", check=False)
            created.append(".git/")
    else:
        print("仓库已存在：%s" % root)

    p = os.path.join(root, ARCHIVES_DIR)
    if not os.path.isdir(p):
        if not args.dry:
            os.makedirs(p, exist_ok=True)
            open(os.path.join(p, ".gitkeep"), "w").close()
        created.append(ARCHIVES_DIR + "/")

    print("已创建：%s" % (", ".join(created) if created else "无（已是最新）"))
    print("本地仓库就绪；要推送请在本地提交并推送（本技能 backup 命令会自动推送）")
    return RC_OK


def cmd_remote(args, root):
    """查看或设置远程地址，并验证可达性。"""
    if not is_repo(root):
        raise Fail("备份仓库还没初始化：先跑 backup.py init", RC_NOT_INIT)
    if args.show or not args.url:
        url = remote_url(root)
        print("origin = %s" % (url or "（未配置）"))
        repo = repo_env()
        if repo and "/" in repo:
            print("%s = %s → https://github.com/%s.git" % (ENV_REPO, repo, repo))
        return RC_OK
    if not args.url:
        repo = repo_env()
        if not repo:
            raise Fail("缺少 --url，也未设置 %s\n%s"
                       % (ENV_REPO, env_guide([ENV_REPO])))
        args.url = "https://github.com/%s.git" % repo
    if args.dry:
        print("将设置 origin = %s" % args.url)
        return RC_OK
    if remote_url(root):
        git(root, "remote", "set-url", "origin", args.url)
    else:
        git(root, "remote", "add", "origin", args.url)
    print("已设置 origin = %s" % args.url)
    tok = token()
    if not tok:
        print("未设置 %s，推送时会被拒绝" % ENV_TOKEN)
        return RC_OK
    rc, out, err = run_remote(root, args.url, tok, ["ls-remote", "--heads"])
    if rc == 0:
        print("远程可访问：%s" % (out.splitlines()[0] if out else "（空仓库）"))
    else:
        print("远程无法访问：%s" % (err or out))
    return RC_OK


# ---------------------------------------------------------------- 下载还原

def move_to_bak(root, keep=("bak",)):
    """把挂载根下除 bak/ 之外的所有条目移进 bak/<时间戳>/。

    返回 (收件箱目录, 移动的条目数)。bak/ 已存在时追加时间戳子目录，永不覆盖。
    """
    bak = os.path.join(root, "bak")
    os.makedirs(bak, exist_ok=True)

    stamp_dir = os.path.join(bak, human_stamp())
    n = 1
    while os.path.exists(stamp_dir):
        n += 1
        stamp_dir = os.path.join(bak, "%s (%d)" % (human_stamp(), n))
    os.makedirs(stamp_dir)

    moved = 0
    for name in sorted(os.listdir(root)):
        if name in keep:
            continue
        src = os.path.join(root, name)
        dst = os.path.join(stamp_dir, name)
        try:
            os.rename(src, dst)
        except OSError:
            # 跨设备或挂载盘不支持 rename 时退化为复制 + 删除
            if os.path.isdir(src) and not os.path.islink(src):
                shutil.copytree(src, dst, symlinks=True)
                shutil.rmtree(src, ignore_errors=True)
            else:
                shutil.copy2(src, dst, follow_symlinks=False)
                os.remove(src)
        moved += 1
    return stamp_dir, moved


def restore_into_root(stage, root):
    """把 stage 里的全部条目移回挂载根（覆盖同名，但已在 bak/ 里留了原件）。"""
    moved = 0
    for name in sorted(os.listdir(stage)):
        if name in ("archives", "restore", "bak"):
            continue  # 这几类是本地产物，不进根目录（.git 必须保留）
        src = os.path.join(stage, name)
        dst = os.path.join(root, name)
        if os.path.isdir(dst) and not os.path.islink(dst):
            shutil.rmtree(dst, ignore_errors=True)
        elif os.path.exists(dst):
            os.remove(dst)
        try:
            os.rename(src, dst)
        except OSError:
            if os.path.isdir(src) and not os.path.islink(src):
                shutil.copytree(src, dst, symlinks=True)
            else:
                shutil.copy2(src, dst, follow_symlinks=False)
        moved += 1
    return moved


def extract_packs(stage):
    """解开 stage 里所有 *.git.tar.gz 并删除包。返回 (包数, 残留包数)。"""
    packs = []
    for dp, _, fns in os.walk(stage):
        for n in fns:
            if n.endswith(".git.tar.gz"):
                packs.append(os.path.join(dp, n))
    for p in sorted(packs):
        rel = os.path.relpath(p, stage)
        try:
            with tarfile.open(p, "r:gz") as tar:
                try:
                    tar.extractall(stage, filter="data")
                except TypeError:  # Python < 3.12 没有 filter 参数
                    tar.extractall(stage)
        except Exception as e:
            raise Fail("解包失败 %s：%s" % (rel, e))
        os.remove(p)
    left = [f for _, _, fs in os.walk(stage) for f in fs if f.endswith(".git.tar.gz")]
    return len(packs), len(left)


def cmd_restore(args, root):
    """从远程拉回备份并自动还原到挂载根。

    顺序很重要：旧内容先整体挪进 bak/，再把备份铺回根目录。
    """
    if not is_repo(root):
        raise Fail("备份仓库还没初始化：先跑 backup.py init", RC_NOT_INIT)
    tok, owner, name = github_env()
    url = args.remote or remote_url(root) or "https://github.com/%s/%s.git" % (owner, name)
    if not remote_matches(url, owner, name) and is_network_url(url):
        raise Fail("还原地址 %s 与 %s=%s/%s 不匹配" % (url, ENV_REPO, owner, name))

    stage = tempfile.mkdtemp(prefix="minis-restore-")
    try:
        print("克隆到临时目录 %s ..." % stage)
        rc, out, err = git(stage, "clone", "--depth", "1", authed_url(url, tok), ".", check=False)
        if rc != 0:
            msg = "克隆失败：%s" % mask(err or out, tok)
            hint = explain_push_error(err or out)
            if hint:
                msg += "\n原因：%s" % hint
            raise Fail(msg)

        # 克隆出的 .git 保留：它就是备份仓库本身，铺回根目录后仓库直接可用
        npacks, left = extract_packs(stage)
        if npacks == 0:
            print("远程备份里没有 *.git.tar.gz，根目录未改动")
            return RC_OK
        print("解开 %d 个备份包%s" % (npacks, "" if not left else "（%d 个未解）" % left))

        bak_dir, moved = move_to_bak(root)
        print("原目录 %d 个条目已移入：%s" % (moved, bak_dir))

        n = restore_into_root(stage, root)
        print("备份已铺回根目录：%d 个条目" % n)

        if args.dry:
            print("（预演结束；要真正还原请去掉 --dry）")
            return RC_OK
        print("还原完成：%s" % root)
        print("原文件保留在 %s，确认无误后可自行删除" % bak_dir)
        return RC_OK
    finally:
        shutil.rmtree(stage, ignore_errors=True)


# ---------------------------------------------------------------- CLI

def build_parser():
    p = argparse.ArgumentParser(prog="backup.py", description="Minis 挂载目录的 GitHub 备份")
    p.add_argument("--version", action="version", version="minis-git-backup " + VERSION)
    p.add_argument("--mount", help="挂载目录（默认 /var/minis/mounts/Minis）")
    sub = p.add_subparsers(dest="cmd")

    i = sub.add_parser("init", help="初始化本地备份仓库（不联网）")
    i.add_argument("--dry", action="store_true", help="只预演")

    rm = sub.add_parser("remote", help="查看或设置远程仓库地址")
    rm.add_argument("--url", help="GitHub 仓库地址")
    rm.add_argument("--show", action="store_true", help="只打印当前地址")
    rm.add_argument("--dry", action="store_true", help="只预演")

    b = sub.add_parser("backup", help="打包并提交推送")
    b.add_argument("--local", action="store_true", help="只本地提交，不推送")
    b.add_argument("--dry", action="store_true", help="只打包，不提交")
    b.add_argument("-m", "--message", help="提交信息")
    b.add_argument("--keep-archives", action="store_true",
                   help="提交后保留本地包（默认删除）")
    b.add_argument("--remote", help="覆盖推送地址（默认取 origin）")

    sc = sub.add_parser("scan", help="扫描 memory 的敏感信息")
    sc.add_argument("--fix", action="store_true", help="就地打码")

    r = sub.add_parser("restore", help="从远程下载并还原到挂载根")
    r.add_argument("--remote", help="远程地址（默认取 origin）")
    r.add_argument("--dry", action="store_true", help="只解包到临时目录，不动根目录")
    return p


def main(argv):
    parser = build_parser()
    args = parser.parse_args(argv)
    if not args.cmd:
        parser.print_help()
        return RC_USAGE
    if getattr(args, "mount", None):
        os.environ[MOUNT_ENV] = args.mount
    try:
        root = mount_root()
        if args.cmd == "init":
            return cmd_init(args, root)
        if args.cmd == "remote":
            return cmd_remote(args, root)
        if args.cmd == "backup":
            return cmd_backup(args, root)
        if args.cmd == "scan":
            return cmd_scan(args, root)
        if args.cmd == "restore":
            return cmd_restore(args, root)
        return RC_USAGE
    except Fail as e:
        print("错误：%s" % e)
        return e.rc
    except KeyboardInterrupt:
        return RC_FAIL


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
