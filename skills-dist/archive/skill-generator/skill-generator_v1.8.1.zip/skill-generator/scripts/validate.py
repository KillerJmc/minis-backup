#!/usr/bin/env python3
"""技能结构校验：不自动改写，只报问题。

用法:
    python3 validate.py <技能目录> [--json]
退出码: 0 无 ERROR / 1 有 ERROR / 2 用法错误
"""
import json
import re
import sys
from pathlib import Path

MAX_DESC = 200
MAX_TRIGGERS = 50
MAX_BODY_LINES = 500


def norm(s: str) -> str:
    """忽略空白与常见标点后再比较，避免标点差异造成误报。"""
    return re.sub(r"[\s，。、；：！？,.;:!?（）()「」\"']+", "", s)


def split_front(text: str):
    if not text.startswith("---"):
        return None, text
    end = text.find("\n---", 3)
    if end == -1:
        return None, text
    head = text[3:end]
    body = text[end + 4:].lstrip("\n")
    meta = {}
    for line in head.splitlines():
        if ":" in line:
            k, v = line.split(":", 1)
            meta[k.strip()] = v.strip()
    return meta, body


def check(skill_dir: Path):
    errs, warns = [], []
    skill_md = skill_dir / "SKILL.md"
    if not skill_md.is_file():
        return [f"缺少 SKILL.md: {skill_md}"], []

    text = skill_md.read_text(encoding="utf-8")
    meta, body = split_front(text)

    if meta is None:
        errs.append("缺少 frontmatter（文件需以 --- 开头并以 --- 结尾）")
        meta = {}

    for key in ("name", "description", "version", "triggers"):
        if not meta.get(key):
            errs.append(f"frontmatter 缺少 {key}")

    name = meta.get("name", "")
    if name and name != skill_dir.name:
        errs.append(f"name ({name}) 与目录名 ({skill_dir.name}) 不一致")

    desc = meta.get("description", "")
    if desc and len(desc) > MAX_DESC:
        errs.append(f"description 过长：{len(desc)} > {MAX_DESC} 字符，会被截断")

    trig = meta.get("triggers", "")
    if trig and len(trig) > MAX_TRIGGERS:
        errs.append(f"triggers 过长：{len(trig)} > {MAX_TRIGGERS} 字符")

    # CHANGELOG.md：必带，最新版本号必须与 SKILL.md 的 version 一致
    cl = skill_dir / "CHANGELOG.md"
    if not cl.is_file():
        errs.append("缺少 CHANGELOG.md：每个版本改了什么必须随技能发布")
    else:
        cl_text = cl.read_text(encoding="utf-8")
        vers = re.findall(r"^(\d+\.\d+\.\d+)\s*·\s*(\S+)\s*$", cl_text, re.M)
        if not vers:
            errs.append("CHANGELOG.md 里没有 `x.y.z · 日期` 形式的版本行")
        else:
            nums = [v[0] for v in vers]
            if nums != sorted(nums, key=lambda s: [int(x) for x in s.split(".")], reverse=True):
                warns.append(f"CHANGELOG.md 版本未按降序排列：{', '.join(nums[:4])}")
            ver = meta.get("version", "")
            if re.fullmatch(r"\d+\.\d+\.\d+", ver) and nums[0] != ver:
                errs.append(f"CHANGELOG.md 最新版本 {nums[0]} 与 SKILL.md 的 version {ver} 不一致")
        if not re.search(r"^[-*] .+[：:]", cl_text, re.M):
            warns.append("CHANGELOG.md 没有 `- 小标题：内容` 形式的条目")

    if not re.fullmatch(r"\d+\.\d+\.\d+", meta.get("version", "")):
        warns.append(f"version 不是 x.y.z 形式：{meta.get('version')!r}")

    lines = [l for l in body.splitlines() if l.strip()]
    if len(lines) > MAX_BODY_LINES:
        errs.append(f"正文过长：{len(lines)} > {MAX_BODY_LINES} 行，细节应下沉 references/")

    if not lines:
        errs.append("正文为空")
    else:
        first = lines[0].strip()
        if first.startswith("#"):
            errs.append("正文第一句是标题；App 描述栏会显示成 Markdown 符号，应写一句话功能")
        elif desc and norm(first) != norm(desc):
            errs.append(f"正文首句与 description 不一致：\n      首句: {first}\n      描述: {desc}")

    if "## 功能" not in body:
        errs.append("缺少「## 功能」表：应列出用户能主动触发的事")

    if re.search(r"^\|\s*F\d+\s*\|", body, re.M) or re.search(r"\bF[1-9]\b", body):
        warns.append("正文出现 F1/F2 之类编号，建议去掉")

    refs = skill_dir / "references"
    if refs.is_dir() and "references/" not in body:
        warns.append("存在 references/ 但正文未指向它")

    scripts = list((skill_dir / "scripts").glob("*.py")) if (skill_dir / "scripts").is_dir() else []
    if scripts and not (skill_dir / "tests").is_dir():
        warns.append("有 scripts/ 但没有 tests/，脚本行为没有回归保护")

    # 两层目录：技能目录是内层，工程文件（PROJECT.md / PROGRESS.md）在外层。
    # 只有外层确实像工程层时才检查，避免对单独拷出来的技能误报。
    # 判据用工程文档与临时目录，不依赖 deploy.py —— 那个已经归 skill-generator 统一提供。
    parent = skill_dir.parent
    is_project_layer = ((parent / "PROJECT.md").is_file()
                        or (parent / "PROGRESS.md").is_file()
                        or (parent / "temp").is_dir()
                        or (parent / ".tmp").is_dir())

    # 工作副本本来就该在自己的 git 仓库里，deploy 会排除 .git，所以工程层下的 .git 不算问题；
    # 只有孤立的技能目录（或部署产物）带 .git 才说明仓库元数据可能被一起拷进去了。
    if (skill_dir / ".git").exists() and not is_project_layer:
        warns.append("技能目录里有 .git 且上层不是工程层：部署产物不应包含仓库元数据，deploy 时要排除")

    if is_project_layer:
        for f in ("PROJECT.md", "PROGRESS.md"):
            if not (parent / f).is_file():
                warns.append(f"工程层 {parent.name}/ 缺少 {f}：项目介绍与进度应放在技能目录的上一层")
        for f in ("PROJECT.md", "PROGRESS.md", "WORKFLOW.md", "deploy.py"):
            if (skill_dir / f).exists():
                warns.append(f"技能目录里不应有 {f}：那是工程层文件，放上一层")
        docs = parent / "docs"
        if docs.is_dir():
            pm = parent / "PROJECT.md"
            ptxt = pm.read_text(encoding="utf-8") if pm.is_file() else ""
            for f in sorted(docs.glob("*.md")):
                if f.name not in ptxt:
                    warns.append(f"docs/{f.name} 未在 PROJECT.md 里引用：沉淀下来的调研要能从工程介绍找到")

    return errs, warns


def main() -> int:
    args = [a for a in sys.argv[1:] if a != "--json"]
    as_json = "--json" in sys.argv[1:]
    if len(args) != 1:
        print("用法: python3 validate.py <技能目录> [--json]")
        return 2
    d = Path(args[0]).expanduser().resolve()
    if not d.is_dir():
        print(f"❌ 目录不存在: {d}")
        return 2

    errs, warns = check(d)
    if as_json:
        print(json.dumps({"skill": d.name, "errors": errs, "warnings": warns,
                          "ok": not errs}, ensure_ascii=False, indent=1))
    else:
        print(f"检查 {d}")
        for e in errs:
            print(f"  ERROR {e}")
        for w in warns:
            print(f"  WARN  {w}")
        print(f"{len(errs)} 个 ERROR，{len(warns)} 个 WARN")
    return 0 if not errs else 1


if __name__ == "__main__":
    sys.exit(main())
