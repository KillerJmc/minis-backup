---
name: skill-generator
description: 新建技能，改写技能，校验技能结构
version: 1.8.1
triggers: 写技能,新建技能,改技能,技能规范,校验技能

---

新建技能，改写技能，校验技能结构。

## 功能

用户能主动触发的操作。前四件是功能，后四件会动文件或线上，必须用户亲口说：

| 功能 | 触发关键字 | 作用 |
|---|---|---|
| 技能新建 | 写个技能、新建技能、做个技能 | 从功能点出发生成可运行的技能骨架 |
| 技能规范 | 改规范、规范化工程、整理工程 | 把已有工程整理成规范结构 |
| 技能改写 | 改技能、重构、可读性差 | 按判据重排现有技能，不改变行为 |
| 结构校验 | 校验技能、检查技能规范 | 静态检查并列出问题清单 |
| 改动授权 | 改吧、开始改、动手 | 只改工作副本：内容、版本号、变更记录、用例；不提交、不发布 |
| 发布 | 发布、部署、上线 | 先贴本次变更记录，认可后才测试、提交、部署、打包 |
| 打包产物 | 出个包、打包、生成 zip | 只打包不上线：`scripts/deploy.py --pack-only`，源取挂载镜像 |
| 撤销 | 撤销、回滚 | 提交退回上一版、线上退回上一版，改动全保留 |
| 丢弃修改 | 丢弃修改、不要了 | 删除未提交改动，执行前先列清单 |

## 技能新建

先问清三件事，再动笔：

1. **功能点**：用户能主动说出口的几件事（通常 2–5 个）；
2. **触发关键字**：用户会怎么称呼这些事，用他的话，不用技术词；
3. **数据放哪、命令怎么跑**：至少要能用一个命令复现核心动作。

生成两层：外层是工程层（项目文档、上线脚本、临时目录），内层是完整技能目录。
**下面每个目录与文件都必须创建**，没有内容的目录放 `.gitkeep` 占位，不写 `.gitignore` 之外的可选项——"以后再说"的项目最后都成了空缺。

```
projects/<工程名>/                 ← 工程层（工程仓库）
├── PROJECT.md                     项目介绍：是什么、为什么这样设计
├── PROGRESS.md                    进度：做到哪、下一步
├── .gitignore                     排除技能目录与大文件（temp/ 例外入库）
├── temp/                          临时数据、中间稿（进工程仓库）
├── docs/                          调研结论、长文档（无内容时放 .gitkeep）
└── <技能名>/                       ← 技能层（技能仓库，完整技能）
    ├── SKILL.md                   元数据 + 功能表 + 各功能用法 + 执行约束
    ├── references/commands.md     参数、退出码、已知限制
    ├── scripts/                  能力脚本：校验 / 规范化 / 部署，按职责分文件
    ├── tests/{cases.json,run.py,README.md}
    ├── assets/                    可选：模板/图标/字体（无内容不建）
    └── .gitignore
```

两层可以同名（`a-new-skill/a-new-skill/`），不必另起工程名：部署脚本只认含 `SKILL.md` 的子目录，工程文件放外层永远不会混进部署产物。

`PROJECT.md` / `PROGRESS.md` 的模板与更新规则见 [`references/layout.md`](references/layout.md)。

`SKILL.md` 第一行之后必须紧跟一句与 `description` 完全一致的话——Minis 的技能详情页显示的是这句，不是 `description` 字段。

## 技能规范

把已有工程整理成规范结构。**先查名字，再补文件**；名字不对就停。

```sh
python3 /var/minis/skills/skill-generator/scripts/normalize.py          # 预演
python3 /var/minis/skills/skill-generator/scripts/normalize.py --apply  # 执行
```

### 第一步：查名字（只读）

| 检查 | 不通过时 |
|---|---|
| 工程目录名 = App 分组名 | 输出应改的分组名与迁移命令，**退出，不动文件** |
| 每个技能目录名 = 它的 `SKILL.md` 的 `name` | 输出两边各是什么，让用户决定改哪边，**退出** |

退出码 `3` 表示命名不一致已停止，一个文件都没改。

### 第二步：等用户迁移

改名涉及 App 分组与工程迁移，是用户自己的操作，脚本不代做。用户改完分组名、跑完 `ws.py migrate` 后重跑本命令，复查通过才继续。

### 第三步：改造工程层

| 动作 | 说明 |
|---|---|
| 补缺失的工程层文件 | `PROJECT.md`、`PROGRESS.md`、`.gitignore` |
| `.tmp/` → `temp/` | 同时补齐 `.gitignore` 的例外与大文件规则；两者同时存在则停 |
| 建 `CHANGELOG.md` | 技能目录内，只写当前版本一条，不反推历史 |
| 报 `docs/` 未引用 | 只报告，不自动改 `PROJECT.md` |

边界：**不动技能目录里的内容**、不搬技能目录、不删文件、不自动 commit；其他工程一律不碰。

检查项、报告格式与退出码见 [`references/normalize.md`](references/normalize.md)。

## 技能改写

按这四条改，顺序别乱：

| 步骤 | 做什么 | 常见毛病 |
|---|---|---|
| 1 | 只留用户能触发的功能点 | 把内部准备步骤（建目录）、约束（写文件落点）当功能 |
| 2 | 功能名改成概括性动宾 | 用口语当名字（「我在哪」「改名、合并」） |
| 3 | 每个功能写「何时用 → 命令 → 输出怎么读 → 出错怎么办」 | 只写命令，不写输出语义 |
| 4 | 参数、退出码、边界下沉 `references/` | 正文堆细节，一屏看不完 |

改完跑一次结构校验。

## 结构校验

```sh
python3 /var/minis/skills/skill-generator/scripts/validate.py <技能目录>
```

输出 `ERROR` 与 `WARN` 两档：ERROR 必须修，WARN 看情况。

| 退出码 | 含义 |
|---|---|
| 0 | 无 ERROR（可能有 WARN） |
| 1 | 存在 ERROR |
| 2 | 用法错误或目录不存在 |

`--json` 输出结构化结果，供脚本串联。

## 规范要点

| 层 | 规则 |
|---|---|
| 元数据 | `description` 用功能名列举；`triggers` ≤ 50 字符，写用户口语 |
| 正文首句 | 与 `description` 一致，因为它会显示在 App 描述栏 |
| 正文体量 | ≤ 500 行，功能表一屏看完；不编号 |
| 输出格式 | 不靠缩进/对齐表达结构，UI 会吃掉空格 |
| 破坏性操作 | 先 `--dry`；冲突整体中止，不替用户判断 |
| 未知 flag | 不得退化成位置参数 |
| 测试 | 用例覆盖正常/边界/异常；能离线跑，不依赖网络与登录态；末行「失败 0 项」 |
| 测试时机 | 修改阶段不写、不跑；发布前统一补并跑绿 |
| 可选目录 | `assets/` 只在脚本要读模板/图标/字体时才建，**首次生成不建** |
| 目录 | 外层工程层只放 PROJECT.md / PROGRESS.md / temp / docs；内层技能目录放技能本体。工程内不建 WORKFLOW.md、不放 deploy.py 副本 |
| 变更记录 | 技能目录内必带 `CHANGELOG.md`，最新版本号须等于 `version`；格式与规则见 `references/layout.md` |
| 文档分层 | 决策进 PROJECT.md，进度进 PROGRESS.md，调研与长文档进 docs/，运行时参数进技能 references/ |
| 记录时机 | 本轮验证通过即记账提交，不等会话结束；查表见 `references/layout.md` |
| 版本 | 每个技能一个 git 仓库，工程文档另用一个；`/var/minis/skills/` 只是部署产物 |

**`tests/` 两种写法都行**：数据驱动（`cases.json` + `run.py` 逐条造目录断言），或直接在 `run.py` 里写断言。区别只在可读性，硬要求是末行输出「失败 0 项」且能离线复跑。

新建或改写时逐项对照 `references/checklist.md`；好/坏写法见 `references/patterns.md`；两层目录、文档分工、临时文件落点、PROJECT.md / PROGRESS.md 模板、**什么时候改什么时候提交**（含可选文件何时建）见 `references/layout.md`。版本与上线细节见 `references/git-workflow.md`。

## 版本与上线

每个技能一个 git 仓库，放在工程目录下；`/var/minis/skills/` 是部署产物，**永不直接编辑**。

修改阶段只改文件：编辑内容、升 `version`、写 `CHANGELOG.md`、**补测试用例**，但**不跑测试、不提交**。

**什么时候进入发布流程**

- **修改完成即停**：改完文件、写好变更记录后结束这一轮，报告改了什么与当前状态（版本号、线上版本、改动是否已提交），**不主动发起发布确认**。
- **发布确认只在两种情况发起**：用户说「发布」「上线」「部署」；或用户明确问「怎么发布 / 发布要做什么」。
- 除此之外不贴变更记录、不贴文件清单——那是发布流程的第一轮，不是修改的收尾。

发布**分两轮**，不许在一轮里做完：

**第一轮：贴两样，然后停下**

1. **变更记录条目**：本次新增的部分，贴在对话正文里（不是塞在工具输出里）。
2. **改动文件清单**：一张 Markdown 表格，四列——文件 / 类型 / 改动量 / 改了什么。

| 列 | 写法 |
|---|---|
| 文件 | 文件名做成链接，指向工程里的真实文件（`minis://mounts/...`），点开是文件本身 |
| 类型 | `改` / `增` / `删`；删除的文件单独列出，不混在改动里 |
| 改动量 | `+x −y`；新增文件只写 `+x` |
| 改了什么 | 一句话，不超过一行 |

表下写合计：文件数（增几改几删几）、总增删行数。**不贴 diff 正文**，用户要看细节会点名。

「发布吧」「可以发了」只表示可以开始发布流程，**不等于认可条目**；必须等用户明确点头。

**确认的生效条件**

一条确认只对当次贴出的那份内容有效。出现下面任一情况，确认立即作废，必须重贴并重新确认：

- 贴出后任何文件又发生变动——包括 `SKILL.md`、`CHANGELOG.md`、`checklist.md` 这类文档，哪怕只改一行；
- `version` 改变（换版本号等于换内容）；
- 用户确认后又追加了新要求。

**不许给捷径**：不能把「重新过目」和「直接发布」并列成选项让用户选。每次确认都要重新过目当前版本。

**提交前回查**：第二轮 commit 之前，用 `git diff --numstat` 核一遍文件数与增删行数，必须与确认包里写的一致；不一致就退回第一轮重贴，不提交。

**第二轮：用户确认后才提交与上线**

```sh
cd "projects/<工程>/<技能名>"
python3 tests/run.py            # 末行须为「失败 0 项」
git add -A && git commit -m "feat(<范围>): <一句话>"
cd .. && python3 /var/minis/skills/skill-generator/scripts/deploy.py   # 同步 → 推镜像 → 打包归档
```

`deploy.py` 末尾会生成发布产物，源取**挂载镜像**（`mounts/Minis/skills/<技能名>/`）：

| 位置 | 内容 |
|---|---|
| `mounts/Minis/skills-dist/<技能名>_v<版本>.zip` | 只留本次最新一版 |
| `mounts/Minis/skills-dist/archive/<技能名>/<技能名>_v<旧版本>.zip` | 旧版全部挪到这里 |

顺序是**先写新包、成功了再挪旧版**：新包用临时文件 + 原子改名落盘，失败时 `skills-dist` 里的旧包一个都不动。

`skills-dist/`、`skills-dist/archive/<技能名>/` 不存在会自动创建；但**挂载根 `/var/minis/mounts/Minis` 不存在时，所有功能直接拒绝执行**，
提示去「设置 → 挂载外部文件夹」创建后再来——产物全在挂载目录下，没有挂载就无处存放。

**手动出包**（不部署）：

```sh
python3 /var/minis/skills/skill-generator/scripts/deploy.py --pack-only
python3 /var/minis/skills/skill-generator/scripts/deploy.py --pack-only <技能名>
```

不认可条目就继续改，不 commit、不 deploy。

**第二轮之后：汇报结果，不能只说「已发布」**

| 报什么 | 内容 |
|---|---|
| 提交结果 | commit hash、message、涉及文件数、总增删行数 |
| 上线结果 | deploy 输出里实际推送的文件清单、镜像同步是否成功 |
| 产物结果 | zip 文件名、文件数、大小，以及归档了几个旧版 |
| 版本核对 | 工作副本、`/var/minis/skills/`、外部镜像三处版本号 |

格式示例：

```
提交：<hash> <message>（N 个文件，+x −y）
上线：<deploy 推送的文件数与目标目录>，镜像同步<成功/失败>
产物：skills-dist/<技能名>_v<版本>.zip（N 个文件，X KB），归档 M 个旧版
核对：三处均为 v<版本>
```

- **两个仓库各自什么时候 commit 不看同一件事**：技能仓库只在发布时提交（与 commit、deploy 同一时刻，改到一半不动）；工程仓库以「本轮有可记录的事」为触发（改完、有结论、有决策、有沉淀、流程变了都算）；
- **唯一硬绑定**：每次 deploy 成功，工程仓库必须有且仅有一次对应记录；技能仓库可以领先，工程仓库不能领先（记录写“已上线”之前 deploy 必须真成功过）；
- **记账时机**：本轮交付验证通过（测试绿 + deploy 完成 + 三处一致）立刻记账提交，不等会话结束；只读、随手试的、能重建的临时输出不提交；
- 首次提交必须在测试全绿之后，否则第一条历史就是坏的；
- 共享 `deploy.py` 必须先测后写，并排除 `.git`、`__pycache__`；
- commit message **采用 Angular 规范** `<类型>(<范围>): <主题>`（类型取 feat / fix / docs / test / chore 子集，范围用小写英文主题词，标题不加句号、不超过 50 字）；
- 工程仓库里要用 `.gitignore` 排除各技能目录，避免嵌入式仓库；
- 回滚用 `git revert` 后重新 deploy，不要只 reset 不部署。

仓库划分、commit 格式与类型、两个仓库各自的提交触发点、对齐规则、中断补救、分支与 tag 规定、部署必备行为、坑与校验见 `references/git-workflow.md`。

## 撤销与回滚

**撤销和回滚是一件事**：把发布退回去、把提交退回去，但**所有改动文件都保留**，回到“改好了、还没提交”的状态。

### 照这个顺序执行

以工程 `projects/<工程>/`、技能 `<技能名>`、退回目标 `<上次提交>` 为例。

**第 1 步：记下现场**

```sh
cd "projects/<工程>/<技能名>"
git log --oneline -3          # 确认 <上次提交> 是哪一个
git status --short            # 记下现在的改动清单
```

**第 2 步：提交退回，改动保留**

```sh
git reset --soft <上次提交>
git reset -q
git log --oneline -1          # 应显示 <上次提交>
git status --short            # 改动必须还在
grep -m1 '^version' SKILL.md  # 版本号仍是新的
```

**第 3 步：导出旧版本并核对**

```sh
rm -rf /tmp/prev && mkdir -p /tmp/prev
git archive HEAD | tar -x -C /tmp/prev     # 此时 HEAD 就是 <上次提交>
grep -m1 '^version' /tmp/prev/SKILL.md     # 应为旧版本号
```

**第 4 步：备份线上、用旧版本覆盖**

```sh
rm -rf /tmp/now && cp -a /var/minis/skills/<技能名> /tmp/now   # 出错可从这里恢复
rm -rf /var/minis/skills/<技能名>
cp -a /tmp/prev /var/minis/skills/<技能名>
```

**第 5 步：同步镜像**

```sh
python3 /var/minis/skills/project-workspace/scripts/ws.py sync --push
```

**第 6 步：三处核对**

```sh
grep -m1 '^version' /var/minis/skills/<技能名>/SKILL.md
grep -m1 '^version' /var/minis/mounts/Minis/skills/<技能名>/SKILL.md
grep -m1 '^version' "projects/<工程>/<技能名>/SKILL.md"   # 工作区仍应是新版本
```

前两个是旧版本号，第三个是新版本号，且 `git status` 有改动——这才叫“退回去了，改动还在”。

### 不许用什么

- **禁止 `git reset --hard`**：会把未提交的改动一起丢掉，而这里要保住的正是改动。
- **禁止 `git checkout -- .`** 批量还原：同样丢改动。
- **不要用 `git revert` 代替**：它会把改动反向应用，文件内容回到旧版，等于丢掉新改动。
- **禁止整目录删除线上产物再重部署**：会把旧版本也一起毁掉，应逐文件还原。

### 唯一会丢文件的操作：丢弃修改

只有用户明确说「丢弃这些修改」「不要了」才做。**先列清单，再删**，仍然不用 `reset --hard`。

```sh
cd "projects/<工程>/<技能名>"
git status --short          # 清单：M=改过，??=新增未跟踪
git diff --stat             # 每个文件改了多少行
```

**丢弃已跟踪文件的修改**（恢复到上次提交的样子）：

```sh
git restore SKILL.md CHANGELOG.md   # 指定文件，推荐
git restore .                       # 全部，不可撤销，先确认上面清单
```

**删除新增但未跟踪的文件**（如新脚本、新参考文档）：

```sh
git clean -nd -e temp/      # 预演：列出将被删的文件，排除 temp/
git clean -fd -e temp/      # 真删；-e temp/ 保住临时文件
```

`git clean -fdx` **禁止使用**：`-x` 会把 `.gitignore` 忽略的 `temp/` 内容一起删掉。
不加 `-e temp/` 时，`temp/` 里的未跟踪文件也会被删——预演输出里看到 `temp/` 就说明有风险。

**核对**：

```sh
git status --short          # 应为空
grep -m1 '^version' SKILL.md  # 版本号应回到线上那一版
```

### 事后必做

- 三处版本号一致（工作副本、`/var/minis/skills/`、外部镜像）；
- `PROGRESS.md` 记一行：为什么退、退到哪个提交；
- 若是“没等确认就发布”，原因写进 `PROJECT.md` 的关键决定。

## 执行约束

- **技能改动由用户授权**：只有用户明确表示要改（例如「改」「开始改」「按这个改」「动手」）时才修改技能目录里的文件；讨论、提问、给方案、对比写法时只输出文字。关键词只是例子，判断看语义，拿不准就问。
- **工程层不需要授权**：`PROJECT.md`、`PROGRESS.md`、`docs/`、`temp/` 属于记录，随做随记，改完直接提交。
- **修改阶段只改文件**：授权「改」之后编辑工作副本——内容、`version`、`CHANGELOG.md` 条目，**连同测试用例一起写**；但**不跑测试、不 commit、不 deploy**，工作区保持有未提交改动。
- **测试写在这时、跑在发布时**：用例随改动一起写，避免提交时忘了补；但跑测试是发布那一步的事，修改阶段跑了会让人误以为已经验证过。
- **commit 与发布一起做**：用户说发布时，先确认变更记录，认可后才 commit 并 deploy；不认可就继续改。修改与提交、上线三者不在同一时刻。
- **讨论产出统一落 `temp/`**：未获授权前，方案、草稿、调研、对比写法一律写成工程层 `temp/` 里的文件，不写技能目录、不写 `/var/minis/workspace/`、不写 `/var/minis/shared/`。
- **达标才沉淀 `docs/`**：满足收录标准的，才从 `temp/` 重写成 `docs/<主题>-<类型>.md` 并在 `PROJECT.md` 挂引用；其余留在 `temp/`，用完即删。
- **两层目录**：外层工程层只放 `PROJECT.md`、`PROGRESS.md`、`temp/`、`docs/`；内层技能目录放技能本体。工程里**不建 `WORKFLOW.md`、不放 `deploy.py` 副本**——流程见本技能 `references/git-workflow.md`，工具用 `scripts/deploy.py`（在工程目录下执行，或 `--project` 指定）。
- **生成技能时创建 `PROJECT.md` 与 `PROGRESS.md` 骨架**，写在工程层：前者答"为什么这样设计"，后者答"现在到哪、下一步"，两个文件都必须随工程推进维护。
- **`temp/` 进外层 git**（不在 `.gitignore` 里），用来留下「试过什么、抓到了什么」的痕迹；大文件用 `.gitignore` 挡掉，提交用 `chore(temp): …`。
- **不覆盖 `skill-creator`**：它是通用 Anthropic 规范，本技能只管 Minis 落地（App 显示、触发、iSH 环境）。
- 校验只报问题，**不自动改写文件**；改动交给用户确认。
