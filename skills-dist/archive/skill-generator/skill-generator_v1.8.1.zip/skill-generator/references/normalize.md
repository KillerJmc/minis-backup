# 技能规范：检查项与报告格式

把已有工程整理成规范结构。**先查名字，名字不对就停；对上才补文件。**

## 命令

```sh
python3 scripts/normalize.py                 # 检查当前绑定的工程（预演）
python3 scripts/normalize.py projects/foo    # 指定工程
python3 scripts/normalize.py --apply         # 执行改造
python3 scripts/normalize.py --json          # 结构化输出
```

## 退出码

| 码 | 含义 | 接下来 |
|---|---|---|
| 0 | 已合规，或预演/执行完成 | 有 `--apply` 就是改完了 |
| 1 | 执行出错 | 看报错，修完重跑 |
| 2 | 用法错误 / 找不到工程 | 给路径或先绑定工程 |
| 3 | 命名不一致，已停止 | 按提示改名、迁移，然后重跑 |

`3` 是**停止信号**，不是错误：一个文件都没动。

## 第一步：查名字（只读）

| 检查 | 判定方式 | 不一致时 |
|---|---|---|
| 工程目录名 = App 分组名 | `minis-sessions-cli status` 的 `group` vs 工程目录名 | 输出应改的分组名，停止（退出码 3） |

**只有不给路径时才比对分组名**（查的就是当前绑定的工程）。显式传路径说明是在看别的工程，分组名不属于它，比对会把正常工程误判成不一致。
| 技能目录名 = `SKILL.md` 的 `name:` | 对每个含 `SKILL.md` 的子目录逐个比对 | 输出两边各是什么，让用户决定改哪边，停止 |

**不替用户改名、不搬工程。** 改名涉及 App 分组与 `ws.py migrate`，是用户自己的操作；脚本只告诉他要改成什么。

## 第二步：等用户迁移

用户改完分组名、跑完 `ws.py migrate` 后重跑本命令。名字复查通过才进第三步。

## 第三步：改造工程层

| 动作 | 触发条件 | 说明 |
|---|---|---|
| 建 `PROJECT.md` / `PROGRESS.md` | 文件缺失 | 用内置模板；`PROJECT.md` 的关键决定写「暂无」 |
| 建 `.gitignore` | 缺失 | 用标准规则；已存在只**追加**缺失行，不覆盖 |
| `.tmp/` → `temp/` | 只有 `.tmp/` | 同时保证 `.gitignore` 有 `!/temp/` 与大文件规则 |
| 建 `temp/` | 两个都没有 | 放 `.gitkeep` 占位 |
| 建 `CHANGELOG.md` | 技能目录缺 | 只写当前版本一条，**不反推历史** |
| 报 `docs/` 未引用 | `docs/*.md` 未出现在 `PROJECT.md` | 只报告，不改 `PROJECT.md` |


## 边界

- **不动技能目录内容**：`SKILL.md`、`references`、`scripts`、`tests`、`CHANGELOG.md` 的既有内容一律不改（`CHANGELOG.md` 只在缺失时新建）。
- **不搬技能目录**、**不删任何文件**。
- **只处理目标工程**：其他工程文件夹一律不碰。
- `.tmp/` 与 `temp/` 同时存在 → 停止，让人工合并，不猜哪个该留。
- 整个改造过程中工程仓库处于可提交状态，但**不自动 commit**；提交由发布流程统一做。

## 报告示例

命名不一致：

```
检查 /var/minis/mounts/Minis/projects/Quota Usage Skill
  分组：quota
  ⛔ 工程名不一致
     group：quota
     dir：Quota Usage Skill
     请在 App 把会话分组名改为 'quota'（当前目录名是 'Quota Usage Skill'）

⛔ 命名不一致，已停止。改完名字、迁移工程后重跑本命令。
```

结构不全：

```
检查 /var/minis/mounts/Minis/projects/quota
  分组：quota
  ✓ 工程层结构已合规
```

```
检查 /var/minis/mounts/Minis/projects/quota
  分组：quota
  ⚠ docs 未引用：docs/api-research.md（在 PROJECT.md 的目录节里挂一行引用）
  · 将新建 PROJECT.md
  · 将新建 deploy.py
  · 将把 .tmp/ 改名为 temp/
  · 将向 .gitignore 追加 4 行
  · 将为 quota-usage 新建 CHANGELOG.md

预演结束。确认执行请加 --apply
```

## 与其他功能的分工

| 功能 | 边界 |
|---|---|
| 技能新建 | 从零生成，不做改造 |
| **技能规范** | 只管工程层与命名，不改技能内容 |
| 技能改写 | 改 `SKILL.md` / `references` 的组织与写法 |
| 结构校验 | 只读检查，输出 ERROR / WARN |
