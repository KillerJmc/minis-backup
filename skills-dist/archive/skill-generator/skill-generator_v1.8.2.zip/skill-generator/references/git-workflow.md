# 版本与上线细节

## 两个仓库，不要合成一个

| 仓库 | 根目录 | 管什么 | 提交节奏 |
|---|---|---|---|
| **skill 仓库** | 内层 `projects/<工程>/<技能名>/` | SKILL.md、references、scripts、tests | 每次改技能 |
| **工程仓库** | 外层 `projects/<工程>/` | PROJECT.md、PROGRESS.md、deploy 脚本、docs/ | 改流程或补记录 |

两层可以同名（`a-new-skill/a-new-skill/`）：外层目录名 = App 分组名，内层目录名 = 技能名。工程文件全在外层，`deploy.py` 只扫描含 `SKILL.md` 的子目录，所以永远不会被当成技能文件上线。

理由：技能有自己的版本节奏，工程目录的改动不等于技能改动。合成一个仓库时，回滚代码会把工程记录一起回滚，历史也读不清。

工程仓库只需排除技能目录，**其余文件一律入库**——`docs/`、`temp/`、图片、压缩包都不挡：

```gitignore
__pycache__/
*.pyc
.DS_Store

# 技能目录各自是独立 git 仓库，不纳入工程仓库
/<技能名>/
```

多个技能目录就写多行 `/<技能名>/`。

不写 `/*/`：那会连 `docs/`、`assets/` 和所有新建的顶层目录一起排除，实测 `docs/x.md` 会被静默忽略，`git status` 也不提示。

否则 git 会把技能目录当成嵌入式仓库（gitlink），既不跟踪内容也不跟踪变更，`git status` 还一直显示修改。

## 三个命令

```sh
python3 /var/minis/skills/skill-generator/scripts/release.py status
python3 .../release.py prepare <技能名>
python3 .../release.py confirm <hash>        # hash 来自上一条的输出
```

| 命令 | 做什么 |
|---|---|
| `status` | 报当前阶段（改中 / 待发布 / 已同步）、三处版本、未提交改动 |
| `prepare` | 生成确认包（变更记录条目 + 文件清单 + 增删行数）并算 snapshot hash |
| `confirm` | 重算 hash 比对，不一致拒绝；一致才依次 validate → 跑测试 → commit → deploy → 打包 |

`restore` 只打印撤销步骤，不自动执行——撤销自动化误操作代价高于手打。

**顺序由工具保证，不靠记忆**。以前这套流程写了 181 行文字，仍然会漏；现在写错顺序会被 `confirm` 拦下。

## commit message 格式

采用 Angular 提交规范：`<类型>(<范围>): <主题>`，正文与脚注可选。

| 段 | 要求 |
|---|---|
| 类型 | 小写，取子集 `feat` / `fix` / `docs` / `test` / `chore`；需要时可用 `refactor`、`perf`。禁止自创 `update`、`change`、`调整` |
| 范围 | 小写英文主题词（`layout` / `git` / `progress` / `temp`），不写文件名；全局改动可省略 |
| 主题 | 动宾短语，写“做了什么”，不加句号，≤ 50 字 |

**正文只在两种情况写**：改了行为又改了测试期望（否则后人分不清是修错还是放水）；改动有取舍或踩了坑（写清试过什么、为什么没采用）。

格式由 `release.py confirm` 校验，不合规直接拒绝提交。

## 内外仓库的分工边界

- 技能仓库：<500 行的历史应该读得懂——每次改动都能对应一次能力变化；
- 工程仓库：读起来像一本流水账也没关系——它记的是“这天为什么这么定、做到哪了”；
- **同一件事不要两边都写完整版**：决策写 `PROJECT.md`，进度写 `PROGRESS.md`，技能仓库只在 commit message 里一句话交代。

## 版本号

| 变化 | 版本 |
|---|---|
| 新增功能点、行为改变 | minor +1（1.0.0 → 1.1.0） |
| 修 bug、改文案 | patch +1（1.1.0 → 1.1.1） |
| 结构重写、不兼容 | major +1（1.1.0 → 2.0.0） |

`version` 在修改阶段就改好，不要等到发布；`validate.py` 会检查它与变更记录首行一致。

## 坑

| 现象 | 原因 | 处理 |
|---|---|---|
| 部署后 `skills` 里多出 `.git` | deploy 未排除仓库元数据 | 加排除项，删掉已误部署的 `.git` |
| `du -sh .git` 显示 0 | iSH 在挂载卷上不统计目录大小 | 用 `find .git/objects -type f \| wc -l` 确认 |
| 工程仓库里技能目录显示为 `modified` 且 `git add` 无效 | 目录里有自己的 `.git` | 在工程仓库 `.gitignore` 里排除技能目录 |
| 测试一直绿但功能是错的 | 期望值本身按错误设计写的 | 先质疑期望，再改代码 |
