# 版本与上线细节

## 两个仓库，不要合成一个

| 仓库 | 根目录 | 管什么 | 提交节奏 |
|---|---|---|---|
| **skill 仓库** | 内层 `projects/<工程>/<技能名>/` | SKILL.md、references、scripts、tests | 每次改技能 |
| **工程仓库** | 外层 `projects/<工程>/` | PROJECT.md、PROGRESS.md、deploy 脚本、docs/ | 改流程或补记录 |

两层可以同名（`a-new-skill/a-new-skill/`）：外层目录名 = App 分组名，内层目录名 = 技能名。工程文件全在外层，`deploy.py` 只扫描含 `SKILL.md` 的子目录，所以永远不会被当成技能文件上线。

理由：技能有自己的版本节奏，工程目录的改动不等于技能改动。合成一个仓库时，回滚代码会把工程记录一起回滚，历史也读不清。

工程仓库必须 `.gitignore` 掉每个技能目录；`temp/` 本身**要入库**（记录试过什么），只挡掉其中的大文件：

```gitignore
/<技能名>/
temp/**/*.png
temp/**/*.jpg
temp/**/*.pdf
temp/**/*.zip
temp/**/*.mp4
temp/**/*.sqlite
__pycache__/
*.pyc
*.log
.DS_Store
```

否则 git 会把技能目录当成嵌入式仓库（gitlink），既不跟踪内容也不跟踪变更，`git status` 还一直显示修改。

## 工作副本与部署产物

```
项目/src 工作副本（git 管，唯一可改）
      ↓ deploy.py 跑测试，绿了才继续
/var/minis/skills/<技能名>/            ← 部署产物，不进 git
      ↓ sync --push
/var/minis/mounts/Minis/skills/<技能名>/  ← 外部镜像，不进 git
```

规则：

- **只改工作副本**；直接改 `skills/` 会在下次部署被覆盖，且不进历史；
- 部署产物里**不能有 `.git`**（否则仓库元数据被当技能文件同步，另一侧再覆盖回来会冲突）；
- 部署是**镜像式**：工作副本删掉的文件，产物里也要删。

## 初始化一个新技能的仓库

```sh
cd "projects/<工程>"
mkdir -p <技能名> && cd <技能名>
# …写入 SKILL.md / references / scripts / tests…
cat > .gitignore <<'EOF'
__pycache__/
*.pyc
tests/report.md
.DS_Store
EOF
git init -q
git config user.name "Minis Agent"
git config user.email "agent@local"
git add -A
git commit -m "feat: <技能名> v1.0.0 基线（<N> 项测试全绿）"
```

首次提交必须**在测试全绿之后**，否则第一条历史就是坏的。

## 日常改动

```sh
cd "projects/<工程>/<技能名>"
# 改文件 + 补测试用例（cases.json 或 run.py 内断言）
python3 tests/run.py                      # 末行须为「失败 0 项」
git add -A && git commit -m "fix(<范围>): <一句话>"
cd ..
python3 deploy.py --dry                   # 先看会动哪些文件
python3 deploy.py                         # 测 → 同步 skills → 推镜像
```

## commit message 格式

规范明确写明：**采用 Angular 提交规范**（`AngularJS` git commit message conventions），不自己另立一套。
它的官方格式与本技能一致，只是字段含义更严格：

```
<类型>(<范围>): <主题>
<空行>
<正文>
<空行>
<脚注>
```

### 标题行

| 段 | 必填 | Angular 原文要求 | 本技能的落地 |
|---|---|---|---|
| `<类型>` | 是 | 必须是小写类型词之一 | `feat` / `fix` / `docs` / `test` / `chore`（子集） |
| `(<范围>)` | 否 | 名词，描述影响范围 | 小写英文主题词：`layout` / `git` / `route` / `ws` / `tmp` / `progress` / `project` |
| `<主题>` | 是 | 命令式、现在时（"change" 不是 "changed"/"changes"），**不加句号**，≤ 50 字符 | 中文动宾短语，写“做了什么”，不写“改了一些” |

### 类型子集

Angular 原生有 `build`、`ci`、`perf`、`refactor`、`revert`、`style` 等，本技能只取用得上的五个：

| 类型 | Angular 原义 | 这里的用法 |
|---|---|---|
| `feat` | 新功能 | 新功能点或行为变化 |
| `fix` | 修 bug | 修 bug、修文档中的事实错误 |
| `docs` | 只改文档 | 只改 SKILL.md / references / PROJECT.md / PROGRESS.md |
| `test` | 加改测试 | 只加改用例 |
| `chore` | 杂项、不改 src 与 test | 结构、依赖、整理、`temp` 清理 |

需要 `refactor`（重构不改行为）或 `perf`（性能）时可以用，仍属 Angular 范畴；**不要自创 `update`、`change`、`调整` 这类词**。

### 正文与脚注

- **正文**：与标题隔一个空行，说明“为什么”而不是“做了什么”（做了什么标题已经写了）。本技能只在两种情况要求写：
  - 改了行为又改了测试期望——否则后人无法判断“是修正了错误期望”还是“为了让测试变绿而放宽标准”；
  - 改动有取舍或踩了坑——写清“试过什么、为什么没采用”。
- **脚注**：Angular 用来标不兼容变更与关闭 issue。本技能不涉及对外发布 API，一般不用；需要时按 Angular 写法 `BREAKING CHANGE: <说明>`，不要自造格式。

### 示例

```
feat: skill-generator v1.2.0 基线（23 项测试全绿）
docs(layout): 修正 .gitignore 与 tests 描述，补验证过的忽略模板
docs(git): 补内外两仓库的 commit 规定与提交顺序
chore: 建立 skill-generator 工程骨架（技能取自部署产物 v1.2.0）
docs(progress): 记录 v1.2.2
chore(temp): 麦块云接口抓包
```

### 硬约束

- 标题行 ≤ 50 个中文字符（Angular 是 50 个字符，中文按一个字算，别写成一段话）；
- 不加句号结尾；
- 一次 commit 一件事，不要“顺手修了个错别字”混进功能提交；
- 中英文混排时保留英文类型词与范围词的小写，不要写成 `Docs(Layout)`。

## 两个仓库各自什么时候 commit

两个仓库历史独立，不该绑在同一条时间线上。**判据不同，触发点也不同**。

### 技能仓库（`<技能名>/`）：以「代码改完了」为触发

技能仓库记的是**能力变化**，只有技能本体的内容变化才提。

| 什么情况 | 提交吗 | 说明 |
|---|---|---|
| 改了 SKILL.md / references / scripts / tests | ✅ | 主要场景，一个完整改动一次 |
| 改了以后测试绿了 | ✅ 此时才提 | 测试红了不提 |
| 只跑了测试、没改文件 | ❌ | 空提交没有意义 |
| 改到一半、自己知道没写完 | ❌ | 宁可留未提交，也不留半条历史 |
| 同一个改动反复试了三次 | ✅ 合并成一次 | 用 `git add` 挑最终版，不留试错痕迹 |

```sh
cd "projects/<工程>/<技能名>"
python3 tests/run.py                      # 末行须为「失败 0 项」
git status --short                        # 看有哪些改动
git diff --cached --stat                  # 暂存后确认清单
git commit -m "fix(<范围>): <一句话>"
```

### 工程仓库（外层）：以「本轮有可记录的事」为触发

工程仓库记的是**决策与进度**，不是代码。它跟技能仓库**不是一一对应**：一轮讨论可能提 0 次或 2 次工程仓库，也可能对应 0 次技能仓库。

| 什么情况 | 提交吗 | 进哪个文件 |
|---|---|---|
| deploy 成功 | ✅ 立即 | `PROGRESS.md` 当前状态 + 时间线 |
| 只讨论、没改代码，但有结论或新待办 | ✅ | `PROGRESS.md` |
| 做出取舍、或踩了坑 | ✅ | `PROJECT.md` 关键决定 |
| 调研结论沉淀 | ✅ | `docs/` + `PROJECT.md` 引用 |
| 流程、落点变了 | ✅ | `WORKFLOW.md` |
| 真抓到了难复现的数据 | ✅ 单独一条 `chore(temp): …` | `temp/` |
| 手滑改了文档错别字，不影响任何结论 | ❌ | 攒着，下次有实质记录时一起提 |
| 只是问了问题、什么都没改 | ❌ | — |

```sh
cd "projects/<工程>"
git status --short
git add PROGRESS.md                       # 精确加，别 -A
git commit -m "docs(progress): <一句话>"
```

### 两者怎么对齐

```
技能仓库   ───●──────────────●──────●───    能力变化
              │              │      │
deploy         ▼              ▼      ▼        上线
              │              │      │
工程仓库   ─●────────●──────────────●───    记录（次数不一定相等）
```

三条对齐规则：

1. **每次 deploy 成功，工程仓库必须有且仅有一次对应的记录提交**——这是唯一硬绑定的点。
2. **技能仓库可以领先工程仓库**（改完没 deploy 前不提记录），但**工程仓库不能领先**：记录里写“已上线”之前，deploy 必须真的成功过。
3. **一轮结束前，两个仓库都要干净**：`git -C <技能名> status --short` 与工程根目录 `git status --short` 都为空。不为空说明还有没记完的事。

### 中断与补救

| 情况 | 怎么办 |
|---|---|
| 技能仓库已提交，deploy 失败 | **不写“已上线”**；在 `PROGRESS.md` 待办加一条“vX.Y.Z 已提交未上线”，修好后重新 deploy，成功了补时间线 |
| deploy 成功，但发现记录写错 | 直接改 `PROGRESS.md` 再提一次 `docs(progress): …`，不改历史 |
| 提交后立刻发现技能代码有问题、还没 deploy | 可以 `git commit --amend`；**已经 deploy 过的绝不能 amend**，用新 commit 修 |
| 发现上上个版本的记录漏了 | 补一条时间线（按当时日期），并在提交正文写“补记” |

### 其他规定

- **分支**：两个仓库都只用 `master` 单分支，不开 feature 分支——单人单机，分支只增加切换成本；
- **远程**：本机仓库不设 `remote`、不 `push`；要发 GitHub 时另建仓库再推（那时再补 tag 与发布流程）；
- **tag**：不打。版本号已在 `SKILL.md` 的 `version` 和提交记录里，多一处标记就多一处要同步；
- **`git add` 粒度**：默认用 `git add <路径>` 精确添加；确认本轮所有改动都属同一件事时，才用 `git add -A`；
- **一次 commit 一件事**：能用一句话概括就是一件事；概括不了就拆；
- **`temp/` 单独提交**（`chore(temp): …`），不要混进代码提交，否则回滚代码时会连带回滚数据快照。

### commit 类型

| 类型 | 用途 | 典型仓库 |
|---|---|---|
| `feat` | 新功能点或行为变化 | 技能 |
| `fix` | 修 bug、修文档中的事实错误 | 技能 / 工程 |
| `docs` | 只改文档 | 两边都用 |
| `test` | 只加改用例 | 技能 |
| `chore` | 结构、依赖、整理、`temp` 清理 | 两边都用 |

## 内外仓库的分工边界

- 技能仓库：<500 行的历史应该读得懂——每次改动都能对应一次能力变化；
- 工程仓库：读起来像一本流水账也没关系——它记的是“这天为什么这么定、做到哪了”；
- **同一件事不要两边都写完整版**：决策写 `PROJECT.md`，进度写 `PROGRESS.md`，技能仓库只在 commit message 里一句话交代。

## deploy 脚本的必备行为

1. **先跑测试**，末行不是「失败 0 项」就 `return 1`，什么都不写；
2. 复制时**排除** `.git`、`__pycache__`、`report.md`；
3. 删除产物里工作副本已经没有的文件（镜像语义）；
4. 复制完调用 `sync --push` 更新外部镜像；
5. **生成发布产物**：从挂载镜像打包到 `mounts/Minis/skills-dist/<技能名>_v<版本>.zip`，
   成功后再把该技能的旧版 zip 挪到 `mounts/Minis/skills-dist/archive/<技能名>/`；
6. `--dry` 只打印差异与将要做的事，不改盘。

### 打包的顺序与失败处理

```
1) 写 .zip.tmp
2) 校验存在且大小 > 0
3) os.replace(tmp, out)     ← 原子改名
4) 新包确认在位后，才挪旧版
```

先挪旧版再打包是错的：打包失败会留下「旧版已挪走、新版没生成」的空 `skills-dist`。
打包失败时不动任何旧产物；归档失败时新包已在位，旧版留在原处，下次发布再挪。

`skills-dist/` 与 `skills-dist/archive/` 位于挂载根目录，**不属于任何 git 仓库**，二进制产物不入库。

目录缺失分两种：

| 缺失对象 | 处理 |
|---|---|
| `skills-dist/`、`skills-dist/archive/<技能名>/` | 自动创建（`mkdir -p`） |
| **挂载根 `/var/minis/mounts/Minis`** | 直接拒绝执行，提示去「设置 → 挂载外部文件夹」；不在本地磁盘上伪造挂载目录 |

`deploy.py` 在 `main()` 与 `pack_dist()` 开头都调 `require_mount()`。

### 手动出包

```sh
python3 deploy.py --pack-only            # 全部技能
python3 deploy.py --pack-only <技能名>   # 指定技能
python3 deploy.py --pack-only --dry      # 只看将生成什么
```

与发布时自动打包走同一份代码，逻辑一致。

## 撤销与回滚

**同一件事**：提交退回上一版、线上退回上一版，改动全部保留。

### 命令序列

```sh
# 1) 记现场
cd "projects/<工程>/<技能名>"
git log --oneline -3
git status --short

# 2) 提交退回，改动保留
git reset --soft <上次提交>
git reset -q
git log --oneline -1 && git status --short

# 3) 导出旧版本
rm -rf /tmp/prev && mkdir -p /tmp/prev
git archive HEAD | tar -x -C /tmp/prev
grep -m1 '^version' /tmp/prev/SKILL.md

# 4) 备份线上，用旧版本覆盖
rm -rf /tmp/now && cp -a /var/minis/skills/<技能名> /tmp/now
rm -rf /var/minis/skills/<技能名>
cp -a /tmp/prev /var/minis/skills/<技能名>

# 5) 同步镜像
python3 /var/minis/skills/project-workspace/scripts/ws.py sync --push

# 6) 三处核对
grep -m1 '^version' /var/minis/skills/<技能名>/SKILL.md
grep -m1 '^version' /var/minis/mounts/Minis/skills/<技能名>/SKILL.md
grep -m1 '^version' "projects/<工程>/<技能名>/SKILL.md"
```

通过判据：前两个是旧版本号，第三个是新版本号，且工作区 `git status` 有改动。

### 出错恢复

第 4 步之后发现不对，用备份回滚线上：

```sh
rm -rf /var/minis/skills/<技能名>
cp -a /tmp/now /var/minis/skills/<技能名>
python3 /var/minis/skills/project-workspace/scripts/ws.py sync --push
```

### 禁止

- `git reset --hard`、`git checkout -- .`：会丢未提交改动。
- `git revert` 代替撤销：反向提交会把文件改回旧内容，等于丢新改动。
- 未导出旧版本就删线上目录：先 `/tmp/prev` 成功再动线上。

### 唯一会丢文件的：丢弃修改

只有用户明确说「丢弃」「不要了」才做。先列清单再删，不用 `reset --hard`。

```sh
git status --short          # M=改过，??=新增未跟踪
git diff --stat

git restore SKILL.md        # 丢弃指定文件的修改
git restore .               # 丢弃全部已跟踪文件的修改（先确认清单）

git clean -nd -e temp/      # 预演：列出将被删的未跟踪文件，排除 temp/
git clean -fd -e temp/      # 真删新增文件；-e temp/ 保住临时文件

git status --short          # 应为空
grep -m1 '^version' SKILL.md
```

禁止 `git clean -fdx`：`-x` 会连 `.gitignore` 忽略的 `temp/` 一起删。
不加 `-e temp/` 时，`temp/` 里的未跟踪文件也会被删。

### 事后

三处版本一致；`PROGRESS.md` 记原因与退到的提交；没等确认就发布的，把原因写进 `PROJECT.md` 关键决定。

## 版本号

| 变化 | 版本 |
|---|---|
| 新增功能点、行为改变 | minor +1（1.0.0 → 1.1.0） |
| 修 bug、改文案 | patch +1（1.1.0 → 1.1.1） |
| 结构重写、不兼容 | major +1（1.1.0 → 2.0.0） |

`version` 与 commit 一起改，别让线上产物和仓库标签对不上。

## 上线后校验

```sh
diff -r "projects/<工程>/<技能名>" /var/minis/skills/<技能名>      # 允许排除 .git
diff -r /var/minis/skills/<技能名> /var/minis/mounts/Minis/skills/<技能名>
git status --short                                                # 应为空
```

三处必须一致：工作副本、App 权威源、外部镜像。

## 坑

| 现象 | 原因 | 处理 |
|---|---|---|
| 部署后 `skills` 里多出 `.git` | deploy 未排除仓库元数据 | 加排除项，删掉已误部署的 `.git` |
| `du -sh .git` 显示 0 | iSH 在挂载卷上不统计目录大小 | 用 `find .git/objects -type f \| wc -l` 确认 |
| 工程仓库里技能目录显示为 `modified` 且 `git add` 无效 | 目录里有自己的 `.git` | 在工程仓库 `.gitignore` 里排除技能目录 |
| 测试一直绿但功能是错的 | 期望值本身按错误设计写的 | 先质疑期望，再改代码 |
